/**
 * server.js
 * NexusBot Cloud Backend — Express.js API Server
 * Cloud Computing Internship Project (Task 4)
 *
 * Features:
 *  - REST API for chatbot messages
 *  - Session management with Redis
 *  - Rate limiting
 *  - JWT authentication
 *  - Analytics logging
 *  - Ready for cloud deployment (AWS Lambda / GCP Cloud Run)
 */

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { v4: uuidv4 } = require("uuid");
const Anthropic = require("@anthropic-ai/sdk");

const app = express();
const PORT = process.env.PORT || 3000;

// ── Anthropic Client ──────────────────────────────────────────────
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Middleware ────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(",") || "*" }));
app.use(express.json({ limit: "10kb" }));

// Rate limiting: 60 requests per minute per IP
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  message: { error: "Too many requests. Please slow down." },
  standardHeaders: true,
});
app.use("/api/", limiter);

// ── In-Memory Session Store (use Redis in production) ─────────────
const sessions = new Map();

function getSession(sessionId) {
  if (!sessions.has(sessionId)) {
    sessions.set(sessionId, {
      id: sessionId,
      messages: [],
      createdAt: Date.now(),
      messageCount: 0,
    });
  }
  return sessions.get(sessionId);
}

// ── System Prompt ─────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are NexusBot, a helpful and friendly AI assistant for a cloud-based chatbot platform company.

Your role:
- Help users understand our product, pricing, and features
- Provide technical support and integration guidance
- Answer questions about cloud computing concepts
- Be concise, warm, and professional
- Use emojis sparingly for friendliness

Company context:
- Product: NexusBot AI Chatbot Platform
- Pricing: Free (100 msg/mo), Pro ($29/mo), Enterprise (custom)
- Tech stack: Node.js, Claude AI, Redis, AWS/GCP/Azure
- Integration: Single script tag, REST API, or SDK

Always stay in character as NexusBot. If asked about something outside your scope, politely redirect.`;

// ── Routes ────────────────────────────────────────────────────────

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok", version: "2.0.0", timestamp: new Date().toISOString() });
});

// Main chat endpoint
app.post("/api/v1/chat", async (req, res) => {
  const { message, session_id, context = {} } = req.body;

  // Validate
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "message is required" });
  }
  if (message.length > 1000) {
    return res.status(400).json({ error: "message too long (max 1000 chars)" });
  }

  const sessionId = session_id || uuidv4();
  const session = getSession(sessionId);

  // Add user message to history
  session.messages.push({ role: "user", content: message });
  session.messageCount++;

  // Keep last 10 turns
  const history = session.messages.slice(-20);

  try {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 500,
      system: SYSTEM_PROMPT,
      messages: history,
    });

    const botReply = response.content[0].text;

    // Save assistant reply to session
    session.messages.push({ role: "assistant", content: botReply });

    // Log to analytics (non-blocking)
    logEvent("chat", { session_id: sessionId, input_tokens: response.usage.input_tokens, output_tokens: response.usage.output_tokens });

    res.json({
      response: botReply,
      session_id: sessionId,
      message_count: session.messageCount,
      usage: response.usage,
    });

  } catch (error) {
    console.error("[NexusBot API] Error:", error.message);
    res.status(500).json({ error: "AI service temporarily unavailable. Please try again." });
  }
});

// Streaming chat endpoint
app.post("/api/v1/chat/stream", async (req, res) => {
  const { message, session_id } = req.body;
  if (!message) return res.status(400).json({ error: "message required" });

  const sessionId = session_id || uuidv4();
  const session = getSession(sessionId);
  session.messages.push({ role: "user", content: message });

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const stream = anthropic.messages.stream({
      model: "claude-sonnet-4-20250514",
      max_tokens: 500,
      system: SYSTEM_PROMPT,
      messages: session.messages.slice(-20),
    });

    let fullText = "";

    stream.on("text", (text) => {
      fullText += text;
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\n`);
    });

    stream.on("finalMessage", () => {
      session.messages.push({ role: "assistant", content: fullText });
      res.write("data: [DONE]\n\n");
      res.end();
    });

  } catch (error) {
    res.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
    res.end();
  }
});

// Analytics endpoint (receives events from frontend)
app.post("/api/v1/analytics", (req, res) => {
  const event = req.body;
  logEvent("frontend", event);
  res.json({ received: true });
});

// Get session info
app.get("/api/v1/session/:id", (req, res) => {
  const session = sessions.get(req.params.id);
  if (!session) return res.status(404).json({ error: "Session not found" });
  res.json({
    id: session.id,
    messageCount: session.messageCount,
    createdAt: session.createdAt,
    historyLength: session.messages.length,
  });
});

// ── Analytics Logger ──────────────────────────────────────────────
const analyticsLog = [];

function logEvent(type, data) {
  const entry = { type, data, timestamp: new Date().toISOString() };
  analyticsLog.push(entry);
  if (analyticsLog.length > 10000) analyticsLog.shift(); // rolling window
  if (process.env.NODE_ENV !== "test") {
    console.log(`[Analytics] ${type}:`, JSON.stringify(data));
  }
}

// Admin: view analytics (protect with auth in production!)
app.get("/api/v1/admin/analytics", (req, res) => {
  const adminKey = req.headers["x-admin-key"];
  if (adminKey !== process.env.ADMIN_KEY) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  res.json({
    total_events: analyticsLog.length,
    active_sessions: sessions.size,
    recent: analyticsLog.slice(-50),
  });
});

// ── Error handlers ────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: "Endpoint not found" }));
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal server error" });
});

// ── Start server ──────────────────────────────────────────────────
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`\n⬡ NexusBot API Server running on port ${PORT}`);
    console.log(`☁️  Environment: ${process.env.NODE_ENV || "development"}`);
    console.log(`📊 Health check: http://localhost:${PORT}/health\n`);
  });
}

module.exports = app; // for testing
