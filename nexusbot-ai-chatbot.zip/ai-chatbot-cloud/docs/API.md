# NexusBot API Documentation

## Base URL
```
Production:  https://api.nexusbot.io/v1
Development: http://localhost:3000/api/v1
```

## Authentication
All requests require an API key in the Authorization header:
```
Authorization: Bearer YOUR_API_KEY
```

---

## Endpoints

### POST /chat
Send a message to the AI chatbot.

**Request Body:**
```json
{
  "message": "string (required, max 1000 chars)",
  "session_id": "string (optional)",
  "context": {
    "companyContext": "object (optional)"
  }
}
```

**Response:**
```json
{
  "response": "string",
  "session_id": "string",
  "message_count": "number",
  "usage": {
    "input_tokens": "number",
    "output_tokens": "number"
  }
}
```

**Error Responses:**
- `400 Bad Request` — Missing or invalid message
- `429 Too Many Requests` — Rate limit exceeded
- `500 Internal Server Error` — AI service unavailable

---

### POST /chat/stream
Stream the chatbot response using Server-Sent Events.

**Request Body:** Same as `/chat`

**Response:** SSE stream
```
data: {"choices":[{"delta":{"content":"Hello"}}]}
data: {"choices":[{"delta":{"content":"!"}}]}
data: [DONE]
```

---

### GET /session/:id
Retrieve session metadata.

**Response:**
```json
{
  "id": "string",
  "messageCount": "number",
  "createdAt": "timestamp",
  "historyLength": "number"
}
```

---

### POST /analytics
Submit a frontend analytics event.

**Request Body:**
```json
{
  "event": "string",
  "session_id": "string",
  "data": "object"
}
```

---

### GET /health
Health check for load balancers and monitoring.

**Response:**
```json
{
  "status": "ok",
  "version": "2.0.0",
  "timestamp": "ISO 8601 string"
}
```

---

## Rate Limits
- **Free tier:** 100 requests/hour
- **Pro tier:** 1000 requests/hour  
- **Enterprise:** Unlimited

## Error Codes

| Code | Meaning |
|------|---------|
| 400 | Bad Request — check your request body |
| 401 | Unauthorized — invalid API key |
| 429 | Rate Limited — slow down |
| 500 | Server Error — try again later |
