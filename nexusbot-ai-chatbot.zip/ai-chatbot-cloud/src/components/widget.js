/**
 * widget.js
 * NexusBot Embeddable Widget — Single Script Integration
 * Cloud Computing Internship Project (Task 4)
 *
 * Usage on any website:
 *   <script src="https://cdn.nexusbot.io/widget.js"
 *           data-key="YOUR_API_KEY"
 *           data-theme="dark"
 *           data-position="bottom-right">
 *   </script>
 *
 * Zero dependencies. Works on any website.
 */

(function (window, document) {
  "use strict";

  // ── Read config from script tag ─────────────────────────────────
  const scriptTag = document.currentScript || document.querySelector('script[data-key]');
  const CONFIG = {
    apiKey:     scriptTag?.getAttribute("data-key")      || "demo",
    theme:      scriptTag?.getAttribute("data-theme")    || "dark",
    position:   scriptTag?.getAttribute("data-position") || "bottom-right",
    botName:    scriptTag?.getAttribute("data-name")     || "NexusBot",
    greeting:   scriptTag?.getAttribute("data-greeting") || "Hi! How can I help you today? 👋",
    primaryColor: scriptTag?.getAttribute("data-color")  || "#00d4ff",
    accentColor:  scriptTag?.getAttribute("data-accent") || "#7b61ff",
  };

  // ── Inject CSS ─────────────────────────────────────────────────
  function injectStyles() {
    const style = document.createElement("style");
    style.id = "nexusbot-widget-styles";
    style.textContent = `
      #nexusbot-launcher {
        position: fixed;
        ${CONFIG.position.includes("right") ? "right: 24px;" : "left: 24px;"}
        ${CONFIG.position.includes("bottom") ? "bottom: 24px;" : "top: 24px;"}
        width: 60px; height: 60px; border-radius: 50%;
        background: linear-gradient(135deg, ${CONFIG.primaryColor}, ${CONFIG.accentColor});
        border: none; cursor: pointer; z-index: 999998;
        box-shadow: 0 4px 24px rgba(0,0,0,0.3);
        font-size: 1.5rem; display: flex; align-items: center; justify-content: center;
        transition: transform 0.3s, box-shadow 0.3s;
        animation: nb-float 3s ease-in-out infinite;
      }
      #nexusbot-launcher:hover { transform: scale(1.1); box-shadow: 0 8px 30px rgba(0,0,0,0.4); }
      #nexusbot-container {
        position: fixed;
        ${CONFIG.position.includes("right") ? "right: 24px;" : "left: 24px;"}
        ${CONFIG.position.includes("bottom") ? "bottom: 100px;" : "top: 100px;"}
        width: 360px; height: 520px;
        border-radius: 16px; overflow: hidden;
        box-shadow: 0 20px 60px rgba(0,0,0,0.4);
        z-index: 999999;
        display: none; flex-direction: column;
        background: ${CONFIG.theme === "dark" ? "#0d1117" : "#ffffff"};
        border: 1px solid ${CONFIG.theme === "dark" ? "#1e2a3a" : "#e0e0e0"};
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        animation: nb-slide-up 0.3s ease;
      }
      #nexusbot-container.open { display: flex; }
      .nb-header {
        background: linear-gradient(135deg, ${CONFIG.primaryColor}22, ${CONFIG.accentColor}22);
        border-bottom: 1px solid ${CONFIG.theme === "dark" ? "#1e2a3a" : "#e0e0e0"};
        padding: 12px 16px; display: flex; align-items: center; gap: 10px;
      }
      .nb-avatar {
        width: 36px; height: 36px; border-radius: 50%;
        background: linear-gradient(135deg, ${CONFIG.primaryColor}, ${CONFIG.accentColor});
        display: flex; align-items: center; justify-content: center; font-size: 1rem;
      }
      .nb-bot-name { font-weight: 700; font-size: 0.95rem; color: ${CONFIG.theme === "dark" ? "#e8edf5" : "#111"}; }
      .nb-status { font-size: 0.72rem; color: #00ff9d; }
      .nb-close {
        margin-left: auto; background: none; border: none;
        color: ${CONFIG.theme === "dark" ? "#6b7a99" : "#999"}; cursor: pointer; font-size: 1.1rem;
      }
      .nb-messages {
        flex: 1; overflow-y: auto; padding: 12px;
        display: flex; flex-direction: column; gap: 8px;
        scrollbar-width: thin;
      }
      .nb-msg { display: flex; flex-direction: column; max-width: 80%; }
      .nb-bot { align-self: flex-start; }
      .nb-user { align-self: flex-end; }
      .nb-bubble {
        padding: 10px 14px; border-radius: 12px;
        font-size: 0.85rem; line-height: 1.5;
      }
      .nb-bot .nb-bubble {
        background: ${CONFIG.theme === "dark" ? "#161b27" : "#f5f5f5"};
        color: ${CONFIG.theme === "dark" ? "#e8edf5" : "#111"};
        border: 1px solid ${CONFIG.theme === "dark" ? "#1e2a3a" : "#ddd"};
        border-bottom-left-radius: 4px;
      }
      .nb-user .nb-bubble {
        background: linear-gradient(135deg, ${CONFIG.primaryColor}, ${CONFIG.accentColor});
        color: #fff; border-bottom-right-radius: 4px;
      }
      .nb-input-row {
        padding: 10px; border-top: 1px solid ${CONFIG.theme === "dark" ? "#1e2a3a" : "#e0e0e0"};
        display: flex; gap: 8px;
      }
      .nb-input {
        flex: 1; padding: 8px 12px;
        background: ${CONFIG.theme === "dark" ? "#161b27" : "#f9f9f9"};
        border: 1px solid ${CONFIG.theme === "dark" ? "#1e2a3a" : "#ddd"};
        border-radius: 8px; color: ${CONFIG.theme === "dark" ? "#e8edf5" : "#111"};
        font-size: 0.85rem; outline: none;
      }
      .nb-input:focus { border-color: ${CONFIG.primaryColor}; }
      .nb-send {
        background: linear-gradient(135deg, ${CONFIG.primaryColor}, ${CONFIG.accentColor});
        border: none; border-radius: 8px; padding: 8px 12px;
        color: #fff; cursor: pointer; font-size: 1rem;
      }
      .nb-typing { display: flex; gap: 4px; padding: 4px 2px; }
      .nb-dot {
        width: 6px; height: 6px; border-radius: 50%;
        background: ${CONFIG.primaryColor}; opacity: 0.4;
        animation: nb-dot 1.4s infinite;
      }
      .nb-dot:nth-child(2) { animation-delay: 0.2s; }
      .nb-dot:nth-child(3) { animation-delay: 0.4s; }
      .nb-powered {
        text-align: center; font-size: 0.65rem;
        color: ${CONFIG.theme === "dark" ? "#6b7a99" : "#aaa"};
        padding: 4px; border-top: 1px solid ${CONFIG.theme === "dark" ? "#1e2a3a" : "#eee"};
      }
      @keyframes nb-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
      @keyframes nb-slide-up { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
      @keyframes nb-dot { 0%,80%,100%{opacity:0.4;transform:scale(1)} 40%{opacity:1;transform:scale(1.3)} }
      @media (max-width: 420px) {
        #nexusbot-container { width: calc(100vw - 32px); right: 16px; left: 16px; }
      }
    `;
    document.head.appendChild(style);
  }

  // ── Build DOM ───────────────────────────────────────────────────
  function buildWidget() {
    // Launcher button
    const launcher = document.createElement("button");
    launcher.id = "nexusbot-launcher";
    launcher.innerHTML = "💬";
    launcher.setAttribute("aria-label", "Open chat");
    launcher.onclick = toggleWidget;
    document.body.appendChild(launcher);

    // Chat container
    const container = document.createElement("div");
    container.id = "nexusbot-container";
    container.setAttribute("role", "dialog");
    container.setAttribute("aria-label", `${CONFIG.botName} chat widget`);
    container.innerHTML = `
      <div class="nb-header">
        <div class="nb-avatar">⬡</div>
        <div>
          <div class="nb-bot-name">${CONFIG.botName}</div>
          <div class="nb-status">● Online</div>
        </div>
        <button class="nb-close" onclick="window.__nexusbot__.toggle()" aria-label="Close chat">✕</button>
      </div>
      <div class="nb-messages" id="nb-messages"></div>
      <div class="nb-powered">Powered by NexusBot AI ⬡</div>
      <div class="nb-input-row">
        <input class="nb-input" id="nb-input" type="text" placeholder="Type a message..." aria-label="Chat input" />
        <button class="nb-send" id="nb-send" aria-label="Send">➤</button>
      </div>
    `;
    document.body.appendChild(container);

    // Bind events
    document.getElementById("nb-send").onclick = handleSend;
    document.getElementById("nb-input").onkeypress = e => {
      if (e.key === "Enter") handleSend();
    };

    // Show greeting
    addBotMessage(CONFIG.greeting);
  }

  // ── Message helpers ─────────────────────────────────────────────
  function addBotMessage(text) {
    const msgs = document.getElementById("nb-messages");
    const div = document.createElement("div");
    div.className = "nb-msg nb-bot";
    div.innerHTML = `<div class="nb-bubble">${text.replace(/\n/g,"<br/>")}</div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function addUserMessage(text) {
    const msgs = document.getElementById("nb-messages");
    const div = document.createElement("div");
    div.className = "nb-msg nb-user";
    div.innerHTML = `<div class="nb-bubble">${text}</div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function showTypingIndicator() {
    const msgs = document.getElementById("nb-messages");
    const div = document.createElement("div");
    div.id = "nb-typing";
    div.className = "nb-msg nb-bot";
    div.innerHTML = `<div class="nb-bubble"><div class="nb-typing"><div class="nb-dot"></div><div class="nb-dot"></div><div class="nb-dot"></div></div></div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function hideTypingIndicator() {
    const el = document.getElementById("nb-typing");
    if (el) el.remove();
  }

  // ── Toggle widget ───────────────────────────────────────────────
  function toggleWidget() {
    const container = document.getElementById("nexusbot-container");
    const isOpen = container.classList.contains("open");
    if (isOpen) {
      container.classList.remove("open");
    } else {
      container.classList.add("open");
      document.getElementById("nb-input")?.focus();
    }
  }

  // ── Send handler ────────────────────────────────────────────────
  async function handleSend() {
    const input = document.getElementById("nb-input");
    const text = input.value.trim();
    if (!text) return;

    input.value = "";
    addUserMessage(text);
    showTypingIndicator();
    input.disabled = true;

    await new Promise(r => setTimeout(r, 800 + Math.random() * 700));
    hideTypingIndicator();

    // Use pattern engine or API
    let responseText = "Thanks for your message! I'm here to help.";
    if (typeof classifyIntent !== "undefined") {
      const result = classifyIntent(text);
      responseText = result.response;
    }

    addBotMessage(responseText);
    input.disabled = false;
    input.focus();
  }

  // ── Public API ──────────────────────────────────────────────────
  window.__nexusbot__ = {
    toggle: toggleWidget,
    send: addBotMessage,
    config: CONFIG,
    version: "2.0.0"
  };

  // ── Auto-init ───────────────────────────────────────────────────
  function init() {
    injectStyles();
    buildWidget();
    console.log(`[NexusBot Widget v2.0] Initialized — key: ${CONFIG.apiKey} | theme: ${CONFIG.theme}`);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})(window, document);
