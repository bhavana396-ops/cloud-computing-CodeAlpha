/**
 * chatbot.js
 * Core Chatbot Engine — NexusBot
 * Cloud Computing Internship Project (Task 4)
 *
 * Handles: message rendering, typing indicators, UI state, input validation
 */

// ── Render a message bubble in the chat window ────────────────────
function renderMessage(text, role = "bot", followups = []) {
  const container = document.getElementById("chatMessages");
  if (!container) return;

  const msgDiv = document.createElement("div");
  msgDiv.className = `message ${role === "user" ? "user-message" : "bot-message"}`;

  // Format markdown-lite: bold, code, newlines
  const formatted = formatText(text);

  const bubble = document.createElement("div");
  bubble.className = "msg-bubble";
  bubble.innerHTML = formatted;

  msgDiv.appendChild(bubble);

  // Add quick reply buttons for bot messages
  if (role === "bot" && followups && followups.length > 0) {
    const qr = document.createElement("div");
    qr.className = "quick-replies";
    followups.forEach(option => {
      const btn = document.createElement("button");
      btn.textContent = option;
      btn.onclick = () => sendQuick(option);
      qr.appendChild(btn);
    });
    msgDiv.appendChild(qr);
  }

  container.appendChild(msgDiv);
  scrollToBottom(container);
}

// ── Basic markdown-lite formatter ─────────────────────────────────
function formatText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/`([^`]+)`/g, "<code style='background:rgba(0,212,255,0.1);padding:2px 5px;border-radius:3px;font-size:0.85em'>$1</code>")
    .replace(/\n/g, "<br/>");
}

// ── Typing indicator ──────────────────────────────────────────────
function showTyping() {
  const container = document.getElementById("chatMessages");
  if (!container || document.getElementById("typingIndicator")) return;

  const typing = document.createElement("div");
  typing.id = "typingIndicator";
  typing.className = "message bot-message";
  typing.innerHTML = `
    <div class="msg-bubble">
      <div class="typing-indicator">
        <span></span><span></span><span></span>
      </div>
    </div>`;
  container.appendChild(typing);
  scrollToBottom(container);
}

function hideTyping() {
  const el = document.getElementById("typingIndicator");
  if (el) el.remove();
}

// ── Scroll chat to bottom ─────────────────────────────────────────
function scrollToBottom(container) {
  requestAnimationFrame(() => {
    container.scrollTop = container.scrollHeight;
  });
}

// ── Input validation ──────────────────────────────────────────────
function validateInput(text) {
  if (!text || text.trim().length === 0) return false;
  if (text.trim().length > 500) {
    alert("Message too long. Please keep it under 500 characters.");
    return false;
  }
  return true;
}

// ── Main send message function ────────────────────────────────────
async function sendMessage() {
  const input = document.getElementById("userInput");
  if (!input) return;

  const text = input.value.trim();
  if (!validateInput(text)) return;

  // Clear input, render user message
  input.value = "";
  renderMessage(text, "user");
  showTyping();

  // Disable input during processing
  input.disabled = true;

  // Simulate realistic response delay (800–1800ms)
  const delay = 800 + Math.random() * 1000;
  await sleep(delay);

  hideTyping();

  // Try AI API first, fall back to patterns
  let result;
  if (typeof NexusBotAPI !== "undefined") {
    result = await NexusBotAPI.send(text);
  } else if (typeof classifyIntent !== "undefined") {
    result = classifyIntent(text);
    result = { text: result.response, followups: result.followups };
  } else {
    result = {
      text: "⚠️ Chatbot engine not loaded. Please refresh the page.",
      followups: []
    };
  }

  renderMessage(result.text, "bot", result.followups || []);
  input.disabled = false;
  input.focus();
}

// ── Quick reply shortcut ──────────────────────────────────────────
function sendQuick(text) {
  const input = document.getElementById("userInput");
  if (input) input.value = text;
  sendMessage();
}

// ── Key handler (Enter to send) ───────────────────────────────────
function handleKey(event) {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
}

// ── Utility ───────────────────────────────────────────────────────
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ── Initialize on DOM load ────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("userInput");
  if (input) {
    input.focus();
    console.log("[NexusBot] Chatbot engine initialized ✓");
  }
});
