/**
 * api.js
 * Cloud AI API Integration Layer
 * NexusBot — Cloud Computing Internship Project (Task 4)
 *
 * Handles: REST calls, session management, error handling, streaming
 */

const NexusBotAPI = (() => {

  // ── Configuration ──────────────────────────────────────────────────
  const CONFIG = {
    baseURL: "https://api.nexusbot.io/v1",      // Production endpoint
    localURL: "http://localhost:3000/api/v1",    // Local dev endpoint
    apiKey: window.NEXUSBOT_API_KEY || "demo-key",
    model: "nexusbot-commercial-v2",
    maxTokens: 500,
    temperature: 0.7,
    sessionTimeout: 30 * 60 * 1000,             // 30 minutes
  };

  // ── Session Management ─────────────────────────────────────────────
  let sessionId = generateSessionId();
  let conversationHistory = [];
  let sessionStartTime = Date.now();

  function generateSessionId() {
    return "nbsess_" + Math.random().toString(36).substring(2, 15);
  }

  function checkSessionExpiry() {
    if (Date.now() - sessionStartTime > CONFIG.sessionTimeout) {
      sessionId = generateSessionId();
      conversationHistory = [];
      sessionStartTime = Date.now();
      console.log("[NexusBot] Session refreshed:", sessionId);
    }
  }

  function addToHistory(role, content) {
    conversationHistory.push({ role, content, timestamp: new Date().toISOString() });
    // Keep last 10 turns (20 messages) in context
    if (conversationHistory.length > 20) {
      conversationHistory = conversationHistory.slice(-20);
    }
  }

  // ── Primary: AI-Powered Response ───────────────────────────────────
  /**
   * Send message to the cloud AI backend
   * Falls back to pattern-based if API unavailable
   */
  async function sendToAI(userMessage, context = {}) {
    checkSessionExpiry();
    addToHistory("user", userMessage);

    // Build system prompt for commercial chatbot context
    const systemPrompt = `You are NexusBot, a helpful AI assistant for a cloud-based chatbot platform company. 
You help users with: pricing plans, product features, technical integration, support issues, and cloud deployment questions.
Be concise, friendly, and professional. Use emojis sparingly for warmth.
Company context: ${JSON.stringify(context.companyContext || {})}
Current session: ${sessionId}`;

    const payload = {
      model: CONFIG.model,
      session_id: sessionId,
      system: systemPrompt,
      messages: conversationHistory.map(msg => ({
        role: msg.role,
        content: msg.content
      })),
      max_tokens: CONFIG.maxTokens,
      temperature: CONFIG.temperature,
      stream: false
    };

    try {
      const response = await fetch(`${CONFIG.baseURL}/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${CONFIG.apiKey}`,
          "X-Session-ID": sessionId,
          "X-Client-Version": "2.0.0"
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      const botReply = data.choices?.[0]?.message?.content || data.response;

      addToHistory("assistant", botReply);
      logAnalytics("api_response", { intent: data.intent, confidence: data.confidence });

      return { text: botReply, source: "ai", intent: data.intent };

    } catch (error) {
      console.warn("[NexusBot] API unavailable, falling back to patterns:", error.message);
      return fallbackToPatterns(userMessage);
    }
  }

  // ── Fallback: Pattern-Based Response ──────────────────────────────
  function fallbackToPatterns(userMessage) {
    if (typeof classifyIntent === "undefined") {
      return {
        text: "I'm having trouble connecting to my brain right now. Please try again in a moment! 🔄",
        source: "error",
        intent: "error"
      };
    }
    const matched = classifyIntent(userMessage);
    addToHistory("assistant", matched.response);
    logAnalytics("pattern_response", { intent: matched.intent });
    return {
      text: matched.response,
      followups: matched.followups,
      source: "pattern",
      intent: matched.intent
    };
  }

  // ── Streaming Response (for real-time feel) ────────────────────────
  async function streamResponse(userMessage, onChunk, onComplete) {
    checkSessionExpiry();
    addToHistory("user", userMessage);

    try {
      const response = await fetch(`${CONFIG.baseURL}/chat/stream`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${CONFIG.apiKey}`,
        },
        body: JSON.stringify({
          model: CONFIG.model,
          messages: conversationHistory,
          stream: true
        })
      });

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n").filter(l => l.startsWith("data: "));

        for (const line of lines) {
          const jsonStr = line.replace("data: ", "").trim();
          if (jsonStr === "[DONE]") continue;
          try {
            const data = JSON.parse(jsonStr);
            const token = data.choices?.[0]?.delta?.content || "";
            fullText += token;
            onChunk(token);
          } catch {}
        }
      }

      addToHistory("assistant", fullText);
      onComplete(fullText);

    } catch (error) {
      console.warn("[NexusBot] Streaming failed:", error);
      const result = fallbackToPatterns(userMessage);
      onComplete(result.text);
    }
  }

  // ── Analytics & Logging ───────────────────────────────────────────
  const analytics = { sessions: 0, messages: 0, intents: {}, errors: 0 };

  function logAnalytics(event, data = {}) {
    analytics.messages++;
    if (data.intent) {
      analytics.intents[data.intent] = (analytics.intents[data.intent] || 0) + 1;
    }

    // Send to analytics endpoint (non-blocking)
    const payload = {
      event,
      session_id: sessionId,
      timestamp: new Date().toISOString(),
      ...data
    };

    // Fire-and-forget analytics ping
    fetch(`${CONFIG.baseURL}/analytics`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${CONFIG.apiKey}` },
      body: JSON.stringify(payload)
    }).catch(() => {}); // Silently fail - analytics is non-critical
  }

  function getAnalytics() {
    return { ...analytics, sessionId, historyLength: conversationHistory.length };
  }

  // ── Public API ────────────────────────────────────────────────────
  return {
    send: sendToAI,
    stream: streamResponse,
    fallback: fallbackToPatterns,
    getSession: () => sessionId,
    getHistory: () => [...conversationHistory],
    clearHistory: () => { conversationHistory = []; },
    analytics: getAnalytics
  };

})();

// Expose globally
window.NexusBotAPI = NexusBotAPI;
