/**
 * patterns.js
 * Pre-trained intent patterns for commercial chatbot use.
 * Task 4: Cloud Computing Internship — NexusBot
 *
 * Structure: { intent, patterns[], response, followups[] }
 */

const INTENT_PATTERNS = [
  // ── GREETINGS ──
  {
    intent: "greeting",
    patterns: ["hello", "hi", "hey", "good morning", "good evening", "what's up", "howdy", "greetings"],
    response: "👋 Hello! I'm NexusBot, your AI assistant. I'm here to help you 24/7. What can I assist you with today?",
    followups: ["Tell me about your services", "What can you do?", "I need support"]
  },

  // ── PRICING ──
  {
    intent: "pricing",
    patterns: ["price", "pricing", "cost", "how much", "plan", "subscription", "fee", "charge", "pay", "billing"],
    response: `💰 Here are our pricing plans:\n\n**Starter** — Free\n• 100 messages/month\n• 1 chatbot\n• Basic analytics\n\n**Pro** — $29/month\n• Unlimited messages\n• 5 chatbots\n• Advanced analytics\n• Priority support\n\n**Enterprise** — Custom\n• Unlimited everything\n• Dedicated infrastructure\n• SLA guarantee\n• White-label option\n\nWould you like to start a free trial? 🚀`,
    followups: ["Start free trial", "Compare plans", "Talk to sales"]
  },

  // ── FEATURES ──
  {
    intent: "features",
    patterns: ["feature", "what can you do", "capabilities", "what do you offer", "services", "functions"],
    response: `⚡ NexusBot offers:\n\n🧠 **AI-Powered** — Generative responses using LLMs\n🎯 **Intent Recognition** — 50+ trained patterns\n☁️ **Cloud-Native** — Auto-scaling infrastructure\n🔌 **Easy Integration** — One script tag deployment\n📊 **Analytics** — Real-time conversation insights\n🌐 **Multi-language** — 20+ languages supported\n🔐 **Secure** — End-to-end encrypted chats\n\nAnything specific you'd like to know more about?`,
    followups: ["How to integrate?", "View pricing", "Start free trial"]
  },

  // ── INTEGRATION ──
  {
    intent: "integration",
    patterns: ["integrate", "integration", "embed", "install", "add to website", "setup", "how to use", "get started"],
    response: `🔌 Integration is super simple! Just 3 steps:\n\n**Step 1** — Sign up and get your API key\n\`\`\`\nhttps://nexusbot.io/signup\n\`\`\`\n\n**Step 2** — Add this to your website's \`<head>\`:\n\`\`\`html\n<script src="https://cdn.nexusbot.io/widget.js"\n  data-key="YOUR_API_KEY">\n</script>\n\`\`\`\n\n**Step 3** — That's it! 🎉 The bot goes live instantly.\n\nNeed help? Our docs are at docs.nexusbot.io`,
    followups: ["View documentation", "API reference", "Talk to support"]
  },

  // ── SUPPORT ──
  {
    intent: "support",
    patterns: ["support", "help", "problem", "issue", "bug", "error", "not working", "broken", "trouble", "assist"],
    response: `🛠️ I'm here to help! Here are your support options:\n\n📧 **Email** — support@nexusbot.io (24hr response)\n💬 **Live Chat** — Available Mon–Fri, 9AM–6PM IST\n📖 **Documentation** — docs.nexusbot.io\n🎫 **Ticket System** — For enterprise clients\n\nCan you describe the issue you're facing? I'll try to resolve it directly! 😊`,
    followups: ["Create support ticket", "View documentation", "Talk to human agent"]
  },

  // ── CLOUD / TECHNOLOGY ──
  {
    intent: "cloud",
    patterns: ["cloud", "aws", "azure", "gcp", "google cloud", "serverless", "kubernetes", "docker", "deployment", "hosting"],
    response: `☁️ NexusBot is fully cloud-native!\n\n**Deployment Options:**\n• AWS Lambda + API Gateway\n• Google Cloud Run\n• Azure Functions\n• Self-hosted Docker\n• Kubernetes clusters\n\n**Scaling:** Auto-scales from 0 to millions of requests\n**Availability:** 99.9% uptime SLA\n**Latency:** <200ms global response time via CDN\n\nWant a demo of our cloud deployment? I can connect you with our solutions team!`,
    followups: ["Cloud pricing", "Self-hosting guide", "Talk to solutions team"]
  },

  // ── ABOUT ──
  {
    intent: "about",
    patterns: ["who are you", "what are you", "about", "tell me about", "what is nexusbot", "company"],
    response: `⬡ **About NexusBot**\n\nNexusBot is an AI-powered chatbot platform built for commercial deployment on the cloud.\n\n🏢 Built as a Cloud Computing Internship Project (Task 4)\n🧠 Powered by state-of-the-art generative AI models\n☁️ Architected for cloud-native deployment\n📊 Used by 500+ businesses worldwide\n\nOur mission: Make intelligent AI conversations accessible to every website.`,
    followups: ["View features", "Check pricing", "Start for free"]
  },

  // ── GOODBYE ──
  {
    intent: "goodbye",
    patterns: ["bye", "goodbye", "see you", "farewell", "later", "take care", "quit", "exit", "done", "that's all"],
    response: `👋 Thanks for chatting! Have a great day!\n\nIf you need help later, I'm available 24/7. Don't hesitate to come back! 😊`,
    followups: []
  },

  // ── THANKS ──
  {
    intent: "thanks",
    patterns: ["thank", "thanks", "thank you", "thx", "appreciate", "helpful", "great job", "awesome"],
    response: `🙏 You're welcome! I'm glad I could help.\n\nIs there anything else you'd like to know about NexusBot?`,
    followups: ["View pricing", "How to integrate?", "No, I'm good!"]
  },

  // ── HUMAN AGENT ──
  {
    intent: "human",
    patterns: ["human", "agent", "real person", "talk to someone", "speak to", "live chat", "representative"],
    response: `👤 Connecting you to a human agent!\n\nOur support team is available:\n🕐 Mon–Fri: 9AM – 6PM IST\n📧 Email: support@nexusbot.io\n\nEstimated wait time: <2 minutes\n\nAlternatively, I can handle most queries instantly. What's the issue you're facing?`,
    followups: ["Create ticket instead", "I'll wait for an agent", "Ask bot instead"]
  },

  // ── DEFAULT / FALLBACK ──
  {
    intent: "fallback",
    patterns: [],
    response: `🤔 I'm not quite sure I understood that. Here's what I can help you with:\n\n• 💰 **Pricing** — Plans and billing\n• ⚡ **Features** — What NexusBot offers\n• 🔌 **Integration** — How to add to your site\n• 🛠️ **Support** — Technical help\n• 👤 **Talk to human** — Connect with our team\n\nWhat would you like to know?`,
    followups: ["Pricing", "Features", "Integration help", "Support"]
  }
];

/**
 * Simple intent classifier — matches user input to pattern
 * @param {string} input
 * @returns {Object} matched intent data
 */
function classifyIntent(input) {
  const lower = input.toLowerCase().trim();

  for (const item of INTENT_PATTERNS) {
    if (item.intent === "fallback") continue;
    for (const pattern of item.patterns) {
      if (lower.includes(pattern)) {
        return item;
      }
    }
  }
  // fallback
  return INTENT_PATTERNS.find(i => i.intent === "fallback");
}

// Export for use in other modules
if (typeof module !== "undefined") {
  module.exports = { INTENT_PATTERNS, classifyIntent };
}
