/**
 * tests/chatbot.test.js
 * NexusBot — Unit & Integration Tests
 * Cloud Computing Internship Project (Task 4)
 */

const request = require("supertest");

// ── Mock Anthropic SDK ─────────────────────────────────────────────
jest.mock("@anthropic-ai/sdk", () => {
  return jest.fn().mockImplementation(() => ({
    messages: {
      create: jest.fn().mockResolvedValue({
        content: [{ text: "Hello! I'm NexusBot, how can I help you?" }],
        usage: { input_tokens: 10, output_tokens: 15 },
      }),
    },
  }));
});

const app = require("../server");

// ── Health Check Tests ─────────────────────────────────────────────
describe("Health Check", () => {
  test("GET /health returns 200 with status ok", async () => {
    const res = await request(app).get("/health");
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe("ok");
    expect(res.body.version).toBeDefined();
    expect(res.body.timestamp).toBeDefined();
  });
});

// ── Chat Endpoint Tests ────────────────────────────────────────────
describe("POST /api/v1/chat", () => {
  test("returns bot response for valid message", async () => {
    const res = await request(app)
      .post("/api/v1/chat")
      .send({ message: "Hello, NexusBot!" });

    expect(res.statusCode).toBe(200);
    expect(res.body.response).toBeDefined();
    expect(res.body.session_id).toBeDefined();
    expect(res.body.message_count).toBe(1);
  });

  test("returns 400 for empty message", async () => {
    const res = await request(app)
      .post("/api/v1/chat")
      .send({ message: "" });

    expect(res.statusCode).toBe(400);
    expect(res.body.error).toBeDefined();
  });

  test("returns 400 for missing message field", async () => {
    const res = await request(app)
      .post("/api/v1/chat")
      .send({});

    expect(res.statusCode).toBe(400);
  });

  test("returns 400 for message exceeding 1000 chars", async () => {
    const res = await request(app)
      .post("/api/v1/chat")
      .send({ message: "a".repeat(1001) });

    expect(res.statusCode).toBe(400);
    expect(res.body.error).toMatch(/too long/i);
  });

  test("maintains session across messages", async () => {
    const firstRes = await request(app)
      .post("/api/v1/chat")
      .send({ message: "What is your name?" });

    const sessionId = firstRes.body.session_id;

    const secondRes = await request(app)
      .post("/api/v1/chat")
      .send({ message: "Tell me about pricing", session_id: sessionId });

    expect(secondRes.body.session_id).toBe(sessionId);
    expect(secondRes.body.message_count).toBe(2);
  });

  test("generates new session_id when not provided", async () => {
    const res1 = await request(app).post("/api/v1/chat").send({ message: "Hi" });
    const res2 = await request(app).post("/api/v1/chat").send({ message: "Hi" });
    expect(res1.body.session_id).not.toBe(res2.body.session_id);
  });
});

// ── Session Endpoint Tests ─────────────────────────────────────────
describe("GET /api/v1/session/:id", () => {
  test("returns session info for existing session", async () => {
    const chatRes = await request(app)
      .post("/api/v1/chat")
      .send({ message: "Hello" });

    const sessionId = chatRes.body.session_id;

    const res = await request(app).get(`/api/v1/session/${sessionId}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.id).toBe(sessionId);
    expect(res.body.messageCount).toBe(1);
  });

  test("returns 404 for non-existent session", async () => {
    const res = await request(app).get("/api/v1/session/fake-session-id-xyz");
    expect(res.statusCode).toBe(404);
  });
});

// ── Analytics Endpoint Tests ───────────────────────────────────────
describe("POST /api/v1/analytics", () => {
  test("accepts analytics events", async () => {
    const res = await request(app)
      .post("/api/v1/analytics")
      .send({ event: "page_view", session_id: "test-123" });

    expect(res.statusCode).toBe(200);
    expect(res.body.received).toBe(true);
  });
});

// ── 404 Tests ──────────────────────────────────────────────────────
describe("Unknown routes", () => {
  test("returns 404 for unknown endpoint", async () => {
    const res = await request(app).get("/api/v1/unknown");
    expect(res.statusCode).toBe(404);
  });
});

// ── Pattern Classifier Tests ───────────────────────────────────────
describe("Intent Pattern Classifier (Unit)", () => {
  // Load the patterns module
  const { classifyIntent, INTENT_PATTERNS } = require("../src/utils/patterns");

  test("classifies greeting intent correctly", () => {
    const result = classifyIntent("hello there");
    expect(result.intent).toBe("greeting");
  });

  test("classifies pricing intent correctly", () => {
    const result = classifyIntent("how much does it cost?");
    expect(result.intent).toBe("pricing");
  });

  test("classifies support intent correctly", () => {
    const result = classifyIntent("I have a problem with the integration");
    expect(result.intent).toBe("support");
  });

  test("classifies goodbye intent correctly", () => {
    const result = classifyIntent("bye, see you later");
    expect(result.intent).toBe("goodbye");
  });

  test("falls back to default for unrecognized input", () => {
    const result = classifyIntent("xyz123 random gibberish @#$");
    expect(result.intent).toBe("fallback");
  });

  test("all intents have a non-empty response", () => {
    INTENT_PATTERNS.forEach(item => {
      expect(item.response).toBeTruthy();
      expect(item.response.length).toBeGreaterThan(10);
    });
  });
});
