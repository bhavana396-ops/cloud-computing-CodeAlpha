// frontend/src/pages/Settings.jsx
import { useState } from "react";
import { Save, Info } from "lucide-react";
import toast from "react-hot-toast";

export default function Settings() {
  const [threshold, setThreshold] = useState(0.85);
  const [fuzzy, setFuzzy] = useState(true);
  const [fields, setFields] = useState("email,phone,name");

  const save = () => {
    // In production, persist to backend via API
    toast.success("Settings saved (applies to new checks)");
  };

  const infoRow = (label, desc) => (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "8px 0", borderBottom: "1px solid var(--border)" }}>
      <Info size={14} style={{ color: "var(--text-muted)", marginTop: 2, flexShrink: 0 }} />
      <div>
        <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-primary)" }}>{label}</div>
        <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)", marginTop: 2 }}>{desc}</div>
      </div>
    </div>
  );

  return (
    <div style={{ padding: "2rem", maxWidth: 640, display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      <div>
        <h1 style={{ fontSize: "1.5rem", fontWeight: 700 }}>Settings</h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem", marginTop: 4 }}>
          Configure the deduplication engine behaviour
        </p>
      </div>

      <div className="card" style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
        {/* Threshold */}
        <div>
          <label className="label">Similarity Threshold — {threshold}</label>
          <input
            type="range" min={0.5} max={1} step={0.01}
            value={threshold}
            onChange={(e) => setThreshold(parseFloat(e.target.value))}
            style={{ width: "100%", accentColor: "var(--accent-green)" }}
          />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.72rem", color: "var(--text-muted)", marginTop: 4 }}>
            <span>0.5 – Permissive</span>
            <span>1.0 – Strict</span>
          </div>
        </div>

        {/* Fingerprint fields */}
        <div>
          <label className="label">Fingerprint Fields (comma-separated)</label>
          <input
            className="input"
            value={fields}
            onChange={(e) => setFields(e.target.value)}
            placeholder="email,phone,name"
          />
          <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginTop: 4 }}>
            Fields used to build the SHA-256 fingerprint for exact-match detection (Layer 1).
          </div>
        </div>

        {/* Fuzzy matching */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontWeight: 600, fontSize: "0.875rem" }}>Fuzzy Matching</div>
            <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>
              Enables Layers 2–4: Levenshtein, Jaro-Winkler, Jaccard, and false-positive classification
            </div>
          </div>
          <button
            onClick={() => setFuzzy((f) => !f)}
            style={{
              width: 44, height: 24, borderRadius: 12, border: "none", cursor: "pointer",
              background: fuzzy ? "var(--accent-green)" : "var(--border-light)",
              position: "relative", transition: "background 0.2s",
            }}
          >
            <div style={{
              width: 18, height: 18, borderRadius: "50%", background: "#fff",
              position: "absolute", top: 3, left: fuzzy ? 22 : 4, transition: "left 0.2s",
            }} />
          </button>
        </div>

        <button className="btn btn-primary" onClick={save} style={{ alignSelf: "flex-start" }}>
          <Save size={14} /> Save Settings
        </button>
      </div>

      {/* Info box */}
      <div className="card">
        <div style={{ fontWeight: 600, fontSize: "0.875rem", marginBottom: "0.75rem" }}>Engine Architecture</div>
        {infoRow("Layer 1 — Fingerprint Hash", "SHA-256 of normalised key fields. O(1) lookup, zero false negatives on exact duplicates.")}
        {infoRow("Layer 2 — Fuzzy Field Similarity", "Levenshtein + Jaro-Winkler per field. Catches typos, name variations, and phone format differences.")}
        {infoRow("Layer 3 — Semantic Token Overlap", "Jaccard coefficient on tokenised string values. Detects paraphrase-level similarity.")}
        {infoRow("Layer 4 — False-Positive Classifier", "Rule-based heuristics that down-grade matches which are likely different people despite surface similarity.")}
      </div>
    </div>
  );
}
