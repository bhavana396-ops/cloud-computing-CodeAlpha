// frontend/src/pages/Dashboard.jsx
import { useEffect, useState } from "react";
import { fetchStats, fetchTimeline } from "../utils/api";
import StatCard from "../components/StatCard";
import { classificationMeta, fmt } from "../utils/classify";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid
} from "recharts";
import {
  Database, ShieldOff, AlertTriangle, CheckCircle2,
  TrendingUp, Clock
} from "lucide-react";

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 8, padding: "10px 14px", fontSize: "0.8rem" }}>
      <div style={{ color: "var(--text-muted)", marginBottom: 6 }}>{label}</div>
      {payload.map((p) => (
        <div key={p.name} style={{ color: p.color, display: "flex", gap: 8 }}>
          <span>{p.name}</span><strong>{p.value}</strong>
        </div>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [timeline, setTimeline] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([fetchStats(), fetchTimeline(7)]).then(([s, t]) => {
      setStats(s.data);
      setTimeline(t.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div style={{ padding: "2rem", display: "flex", flexDirection: "column", gap: "1rem" }}>
        {[...Array(4)].map((_, i) => (
          <div key={i} className="shimmer" style={{ height: 80, borderRadius: 12 }} />
        ))}
      </div>
    );
  }

  const db = stats?.database ?? {};
  const dedup = stats?.deduplication ?? {};
  const recent = stats?.recentActivity ?? [];

  return (
    <div style={{ padding: "2rem", display: "flex", flexDirection: "column", gap: "1.75rem" }}>
      {/* Header */}
      <div>
        <h1 style={{ fontSize: "1.5rem", fontWeight: 700, color: "var(--text-primary)" }}>
          Dashboard
        </h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem", marginTop: 4 }}>
          Real-time overview of database integrity and deduplication performance
        </p>
      </div>

      {/* Stat grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "1rem" }}>
        <StatCard label="Total Records"      value={db.totalRecords ?? 0}      icon={Database}      color="var(--accent-blue)" />
        <StatCard label="Active Records"     value={db.activeRecords ?? 0}      icon={CheckCircle2}  color="var(--accent-green)" />
        <StatCard label="Duplicates Blocked" value={dedup.duplicatesRejected ?? 0} icon={ShieldOff}    color="var(--accent-red)" />
        <StatCard label="False Positives"    value={dedup.falsePositives ?? 0}  icon={AlertTriangle} color="var(--accent-yellow)" />
        <StatCard label="Dedup Rate"         value={dedup.deduplicationRate ?? "0%"} icon={TrendingUp} color="var(--accent-purple)" />
        <StatCard label="Total Checks"       value={dedup.totalChecks ?? 0}     icon={Clock}         color="var(--text-secondary)" />
      </div>

      {/* Chart */}
      <div className="card">
        <div style={{ marginBottom: "1rem", fontWeight: 600, fontSize: "0.875rem", color: "var(--text-primary)" }}>
          Activity Timeline — Last 7 Days
        </div>
        {timeline.length === 0 ? (
          <div style={{ color: "var(--text-muted)", fontSize: "0.875rem", textAlign: "center", padding: "2rem" }}>
            No data yet. Start inserting records to see activity.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={timeline} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
              <defs>
                {[["inserted", "#00ff88"], ["rejected", "#ff4466"], ["flagged", "#ffcc00"]].map(([k, c]) => (
                  <linearGradient key={k} id={`grad-${k}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor={c} stopOpacity={0.25} />
                    <stop offset="95%" stopColor={c} stopOpacity={0} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid stroke="var(--border)" strokeDasharray="4 4" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "var(--text-muted)" }} />
              <YAxis tick={{ fontSize: 11, fill: "var(--text-muted)" }} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="inserted" stroke="#00ff88" fill="url(#grad-inserted)" strokeWidth={2} />
              <Area type="monotone" dataKey="rejected" stroke="#ff4466" fill="url(#grad-rejected)" strokeWidth={2} />
              <Area type="monotone" dataKey="flagged"  stroke="#ffcc00" fill="url(#grad-flagged)"  strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Recent activity */}
      <div className="card">
        <div style={{ marginBottom: "1rem", fontWeight: 600, fontSize: "0.875rem", color: "var(--text-primary)" }}>
          Recent Activity
        </div>
        {recent.length === 0 ? (
          <div style={{ color: "var(--text-muted)", fontSize: "0.875rem" }}>No recent activity.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {recent.map((log, i) => {
              const meta = classificationMeta[log.classification] ?? {};
              return (
                <div
                  key={i}
                  style={{
                    display: "flex", alignItems: "center", gap: 12,
                    padding: "8px 0",
                    borderBottom: i < recent.length - 1 ? "1px solid var(--border)" : "none",
                  }}
                >
                  <span className={`badge ${meta.badge ?? "badge-blue"}`}>{meta.label ?? log.classification}</span>
                  <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)", flex: 1, fontFamily: "'JetBrains Mono', monospace" }}>
                    {log.incomingRecord?.email || log.incomingRecord?.name || "—"}
                  </span>
                  <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>
                    {fmt.date(log.createdAt)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
