// frontend/src/pages/Records.jsx
import { useEffect, useState, useCallback } from "react";
import { fetchRecords, archiveRecord, updateStatus } from "../utils/api";
import { classificationMeta, statusMeta, fmt } from "../utils/classify";
import toast from "react-hot-toast";
import { Search, RefreshCw, Archive, ChevronLeft, ChevronRight } from "lucide-react";

export default function Records() {
  const [records, setRecords] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, total: 0, totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [classFilter, setClassFilter] = useState("");
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchRecords({
        page,
        limit: 15,
        search: search || undefined,
        status: statusFilter || undefined,
        classification: classFilter || undefined,
      });
      setRecords(res.data);
      setPagination(res.pagination);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }, [page, search, statusFilter, classFilter]);

  useEffect(() => { load(); }, [load]);

  const handleArchive = async (id) => {
    try {
      await archiveRecord(id);
      toast.success("Record archived");
      load();
    } catch (e) { toast.error(e.message); }
  };

  return (
    <div style={{ padding: "2rem", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "1.5rem", fontWeight: 700 }}>Records</h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem", marginTop: 4 }}>
            {pagination.total} records in database
          </p>
        </div>
        <button className="btn btn-secondary" onClick={load}>
          <RefreshCw size={14} /> Refresh
        </button>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
        <div style={{ position: "relative", flex: 1, minWidth: 200 }}>
          <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
          <input
            className="input"
            style={{ paddingLeft: 34 }}
            placeholder="Search name, email, phone…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          />
        </div>

        <select
          className="input"
          style={{ width: 150 }}
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
        >
          <option value="">All Statuses</option>
          <option value="active">Active</option>
          <option value="flagged">Flagged</option>
          <option value="archived">Archived</option>
        </select>

        <select
          className="input"
          style={{ width: 180 }}
          value={classFilter}
          onChange={(e) => { setClassFilter(e.target.value); setPage(1); }}
        >
          <option value="">All Classifications</option>
          <option value="unique">Unique</option>
          <option value="near_duplicate">Near Duplicate</option>
          <option value="false_positive">False Positive</option>
        </select>
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.82rem" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)", background: "var(--bg-secondary)" }}>
                {["Name", "Email", "Phone", "Status", "Classification", "Confidence", "Created", ""].map((h) => (
                  <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: "0.72rem", fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", whiteSpace: "nowrap" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading
                ? [...Array(6)].map((_, i) => (
                    <tr key={i}>
                      {[...Array(8)].map((_, j) => (
                        <td key={j} style={{ padding: "12px 14px" }}>
                          <div className="shimmer" style={{ height: 14, width: "80%" }} />
                        </td>
                      ))}
                    </tr>
                  ))
                : records.length === 0
                ? (
                  <tr>
                    <td colSpan={8} style={{ padding: "2.5rem", textAlign: "center", color: "var(--text-muted)" }}>
                      No records found
                    </td>
                  </tr>
                )
                : records.map((r) => {
                    const cMeta = classificationMeta[r.dedupMeta?.classification] ?? {};
                    const sMeta = statusMeta[r.status] ?? {};
                    return (
                      <tr
                        key={r._id}
                        style={{ borderBottom: "1px solid var(--border)", transition: "background 0.1s" }}
                        onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-card-hover)"}
                        onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                      >
                        <td style={{ padding: "10px 14px", color: "var(--text-primary)", fontWeight: 500 }}>{fmt.short(r.name, 22)}</td>
                        <td style={{ padding: "10px 14px", color: "var(--text-secondary)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.78rem" }}>{fmt.short(r.email, 28)}</td>
                        <td style={{ padding: "10px 14px", color: "var(--text-muted)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.78rem" }}>{r.phone || "—"}</td>
                        <td style={{ padding: "10px 14px" }}>
                          <span className={`badge ${sMeta.badge}`}>{sMeta.label}</span>
                        </td>
                        <td style={{ padding: "10px 14px" }}>
                          <span className={`badge ${cMeta.badge}`}>{cMeta.label}</span>
                        </td>
                        <td style={{ padding: "10px 14px", fontFamily: "'JetBrains Mono', monospace", color: "var(--text-muted)", fontSize: "0.78rem" }}>
                          {r.dedupMeta?.confidence != null ? fmt.pct(r.dedupMeta.confidence) : "—"}
                        </td>
                        <td style={{ padding: "10px 14px", color: "var(--text-muted)", whiteSpace: "nowrap", fontSize: "0.75rem" }}>
                          {fmt.date(r.createdAt)}
                        </td>
                        <td style={{ padding: "10px 14px" }}>
                          {r.status !== "archived" && (
                            <button className="btn btn-danger" style={{ padding: "4px 10px", fontSize: "0.72rem" }} onClick={() => handleArchive(r._id)}>
                              <Archive size={12} />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
              }
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 8, padding: "10px 14px", borderTop: "1px solid var(--border)" }}>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>
              Page {pagination.page} / {pagination.totalPages}
            </span>
            <button className="btn btn-secondary" style={{ padding: "4px 10px" }} disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
              <ChevronLeft size={14} />
            </button>
            <button className="btn btn-secondary" style={{ padding: "4px 10px" }} disabled={page >= pagination.totalPages} onClick={() => setPage((p) => p + 1)}>
              <ChevronRight size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
