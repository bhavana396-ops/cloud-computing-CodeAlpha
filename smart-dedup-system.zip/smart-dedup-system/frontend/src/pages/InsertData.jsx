// frontend/src/pages/InsertData.jsx
import { useState } from "react";
import { insertRecord, validateRecord, bulkInsert } from "../utils/api";
import ResultBanner from "../components/ResultBanner";
import toast from "react-hot-toast";
import { PlusCircle, Eye, Upload, Loader2, Trash2 } from "lucide-react";

const EMPTY = { name: "", email: "", phone: "", category: "", externalId: "" };

export default function InsertData() {
  const [form, setForm] = useState(EMPTY);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState("single"); // single | bulk
  const [bulkJson, setBulkJson] = useState("");
  const [bulkResult, setBulkResult] = useState(null);

  const change = (k) => (e) => setForm((p) => ({ ...p, [k]: e.target.value }));

  const handleValidate = async () => {
    setLoading(true); setResult(null);
    try {
      const res = await validateRecord(form);
      setResult({ result: res.result, processingTimeMs: res.processingTimeMs });
      toast("Validation complete (dry-run)", { icon: "🔍" });
    } catch (e) {
      toast.error(e.message);
    } finally { setLoading(false); }
  };

  const handleInsert = async () => {
    setLoading(true); setResult(null);
    try {
      const res = await insertRecord(form);
      setResult({ result: res.result, processingTimeMs: res.processingTimeMs });
      if (res.success) {
        toast.success(res.message);
        setForm(EMPTY);
      } else {
        toast.error(res.message);
      }
    } catch (e) {
      toast.error(e.message);
    } finally { setLoading(false); }
  };

  const handleBulk = async () => {
    let records;
    try { records = JSON.parse(bulkJson); }
    catch { toast.error("Invalid JSON"); return; }
    if (!Array.isArray(records)) { toast.error("Expecting a JSON array"); return; }
    setLoading(true); setBulkResult(null);
    try {
      const res = await bulkInsert(records);
      setBulkResult(res);
      toast.success(`Bulk done — ${res.summary.inserted} inserted, ${res.summary.rejected} rejected`);
    } catch (e) { toast.error(e.message); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ padding: "2rem", maxWidth: 760, display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      <div>
        <h1 style={{ fontSize: "1.5rem", fontWeight: 700 }}>Insert Data</h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem", marginTop: 4 }}>
          Every entry is automatically validated and deduplicated before reaching the database.
        </p>
      </div>

      {/* Mode tabs */}
      <div style={{ display: "flex", gap: 8 }}>
        {["single", "bulk"].map((m) => (
          <button
            key={m}
            className={`btn ${mode === m ? "btn-primary" : "btn-secondary"}`}
            onClick={() => setMode(m)}
          >
            {m === "single" ? <PlusCircle size={14} /> : <Upload size={14} />}
            {m === "single" ? "Single Record" : "Bulk Import"}
          </button>
        ))}
      </div>

      {mode === "single" && (
        <div className="card">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
            {[
              ["name",       "Full Name",    "text",  "Alice Johnson"],
              ["email",      "Email",        "email", "alice@example.com"],
              ["phone",      "Phone",        "text",  "+1-555-000-1234"],
              ["category",   "Category",     "text",  "customer"],
              ["externalId", "External ID",  "text",  "EXT-001"],
            ].map(([key, label, type, placeholder]) => (
              <div key={key}>
                <label className="label">{label}</label>
                <input
                  className="input"
                  type={type}
                  placeholder={placeholder}
                  value={form[key]}
                  onChange={change(key)}
                />
              </div>
            ))}
          </div>

          <div style={{ display: "flex", gap: 10, marginTop: "1.5rem" }}>
            <button className="btn btn-secondary" onClick={handleValidate} disabled={loading}>
              {loading ? <Loader2 size={14} className="spin" /> : <Eye size={14} />}
              Dry-Run Validate
            </button>
            <button className="btn btn-primary" onClick={handleInsert} disabled={loading}>
              {loading ? <Loader2 size={14} /> : <PlusCircle size={14} />}
              Insert to Database
            </button>
            <button className="btn btn-danger" onClick={() => { setForm(EMPTY); setResult(null); }} style={{ marginLeft: "auto" }}>
              <Trash2 size={14} /> Clear
            </button>
          </div>

          {result && (
            <ResultBanner result={result.result} processingTimeMs={result.processingTimeMs} />
          )}
        </div>
      )}

      {mode === "bulk" && (
        <div className="card">
          <label className="label">JSON Array of Records</label>
          <textarea
            className="input"
            rows={12}
            style={{ resize: "vertical", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.8rem" }}
            placeholder={`[\n  { "name": "Alice", "email": "alice@example.com", "phone": "5550001" },\n  { "name": "Bob", "email": "bob@example.com", "phone": "5550002" }\n]`}
            value={bulkJson}
            onChange={(e) => setBulkJson(e.target.value)}
          />
          <div style={{ display: "flex", gap: 10, marginTop: "1rem" }}>
            <button className="btn btn-primary" onClick={handleBulk} disabled={loading}>
              {loading ? <Loader2 size={14} /> : <Upload size={14} />}
              Process Bulk Import
            </button>
          </div>

          {bulkResult && (
            <div style={{ marginTop: "1.5rem", display: "flex", flexDirection: "column", gap: 10 }}>
              {/* Summary */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "0.75rem" }}>
                {[
                  ["Inserted", bulkResult.summary.inserted, "#00ff88"],
                  ["Rejected", bulkResult.summary.rejected, "#ff4466"],
                  ["Flagged",  bulkResult.summary.flagged,  "#ffcc00"],
                ].map(([l, v, c]) => (
                  <div key={l} style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)", borderRadius: 8, padding: "12px 16px", textAlign: "center" }}>
                    <div style={{ fontSize: "1.5rem", fontWeight: 700, color: c, fontFamily: "'JetBrains Mono', monospace" }}>{v}</div>
                    <div style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>{l}</div>
                  </div>
                ))}
              </div>

              {/* Rejected list */}
              {bulkResult.rejected.length > 0 && (
                <div style={{ background: "rgba(255,68,102,0.07)", border: "1px solid rgba(255,68,102,0.25)", borderRadius: 8, padding: "12px 16px" }}>
                  <div style={{ fontSize: "0.75rem", fontWeight: 600, color: "var(--accent-red)", marginBottom: 8 }}>
                    REJECTED RECORDS
                  </div>
                  {bulkResult.rejected.map((r, i) => (
                    <div key={i} style={{ fontSize: "0.78rem", color: "var(--text-secondary)", fontFamily: "'JetBrains Mono', monospace", padding: "2px 0" }}>
                      {r.record?.email || r.record?.name || JSON.stringify(r.record).slice(0, 60)}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
