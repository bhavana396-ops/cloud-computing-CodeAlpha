// frontend/src/pages/Logs.jsx
import { useEffect, useState } from "react";
import { fetchLogs } from "../utils/api";
import { classificationMeta, actionMeta, fmt } from "../utils/classify";
import { RefreshCw, ChevronLeft, ChevronRight } from "lucide-react";
import toast from "react-hot-toast";

export default function Logs() {
  const [logs, setLogs] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, total: 0, totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [classFilter, setClassFilter] = useState("");
  const [actionFilter, setActionFilter] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetchLogs({
        page,
        limit: 20,
        classification: classFilter || undefined,
        action: actionFilter || undefined,
      });
      setLogs(res.data);
      setPagination(res.pagination);
    } catch (e) { toast.error(e.message); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [page, classFilter, actionFilter]);

  return (
    <div style={{ padding: "2rem", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "1.5rem", fontWeight: 700 }}>Audit Logs</h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem", marginTop: 4 }}>
            Full trace of every deduplication decision
          </p>
        </div>
        <button className="btn btn-secondary" onClick={load}><RefreshCw size={14} /> Refresh</button>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: "0.75rem" }}>
        <select className="input" style={{ width: 200 }} value={classFilter} onChange={(e) => { setClassFilter(e.target.value); setPage(1); }}>
          <option value="">All Classifications</option>
          {Object.entries(classificationMeta).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
        <select className="input" style={{ width: 160 }} value={actionFilter} onChange={(e) => { setActionFilter(e.target.value); setPage(1); }}>
          <option value="">All Actions</option>
          <option value="inserted">Inserted</option>
          <option value="rejected">Rejected</option>
          <option value="flagged">Flagged</option>
        </select>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.82rem" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)", background: "var(--bg-secondary)" }}>
                {["Timestamp", "Record", "Classification", "Action", "Confidence", "Time (ms)", "Layer"].map((h) => (
                  <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: "0.72rem", fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", whiteSpace: "nowrap" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading
                ? [...Array(8)].map((_, i) => (
                    <tr key={i}>
                      {[...Array(7)].map((_, j) => (
                        <td key={j} style={{ padding: "10px 14px" }}>
                          <div className="shimmer" style={{ height: 14, width: "80%" }} />
                        </td>
                      ))}
                    </tr>
                  ))
                : logs.length === 0
                ? (
                  <tr>
                    <td colSpan={7} style={{ padding: "2.5rem", textAlign: "center", color: "var(--text-muted)" }}>
                      No logs found
                    </td>
                  </tr>
                )
                : logs.map((log) => {
                    const cMeta = classificationMeta[log.classification] ?? {};
                    const aMeta = actionMeta[log.action] ?? {};
                    return (
                      <tr
                        key={log._id}
                        style={{ borderBottom: "1px solid var(--border)" }}
                        onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-card-hover)"}
                        onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                      >
                        <td style={{ padding: "10px 14px", fontSize: "0.75rem", color: "var(--text-muted)", whiteSpace: "nowrap" }}>
                          {fmt.date(log.createdAt)}
                        </td>
                        <td style={{ padding: "10px 14px", color: "var(--text-secondary)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.78rem" }}>
                          {fmt.short(log.incomingRecord?.email || log.incomingRecord?.name, 30)}
                        </td>
                        <td style={{ padding: "10px 14px" }}>
                          <span className={`badge ${cMeta.badge}`}>{cMeta.label}</span>
                        </td>
                        <td style={{ padding: "10px 14px" }}>
                          <span className={`badge ${aMeta.badge}`}>{aMeta.label}</span>
                        </td>
                        <td style={{ padding: "10px 14px", fontFamily: "'JetBrains Mono', monospace", color: "var(--text-muted)", fontSize: "0.78rem" }}>
                          {log.confidence != null ? fmt.pct(log.confidence) : "—"}
                        </td>
                        <td style={{ padding: "10px 14px", fontFamily: "'JetBrains Mono', monospace", color: "var(--text-muted)", fontSize: "0.78rem" }}>
                          {log.processingTimeMs ?? "—"}
                        </td>
                        <td style={{ padding: "10px 14px", fontFamily: "'JetBrains Mono', monospace", color: "var(--text-muted)", fontSize: "0.78rem" }}>
                          {log.details?.layer ?? "—"}
                        </td>
                      </tr>
                    );
                  })
              }
            </tbody>
          </table>
        </div>

        {pagination.totalPages > 1 && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 8, padding: "10px 14px", borderTop: "1px solid var(--border)" }}>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Page {pagination.page} / {pagination.totalPages}</span>
            <button className="btn btn-secondary" style={{ padding: "4px 10px" }} disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="btn btn-secondary" style={{ padding: "4px 10px" }} disabled={page >= pagination.totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        )}
      </div>
    </div>
  );
}
