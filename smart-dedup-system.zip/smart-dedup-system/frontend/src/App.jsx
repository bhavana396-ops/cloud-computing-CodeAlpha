// frontend/src/App.jsx
import { Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import Records from "./pages/Records";
import InsertData from "./pages/InsertData";
import Logs from "./pages/Logs";
import Settings from "./pages/Settings";

export default function App() {
  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      <Sidebar />
      <main style={{ flex: 1, overflowY: "auto", background: "var(--bg-primary)" }}>
        <Routes>
          <Route path="/"        element={<Dashboard />} />
          <Route path="/records" element={<Records />}   />
          <Route path="/insert"  element={<InsertData />} />
          <Route path="/logs"    element={<Logs />}      />
          <Route path="/settings"element={<Settings />}  />
        </Routes>
      </main>
    </div>
  );
}
