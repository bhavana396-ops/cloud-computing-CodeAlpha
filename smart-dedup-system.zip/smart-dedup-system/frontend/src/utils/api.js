// frontend/src/utils/api.js
import axios from "axios";

const api = axios.create({
  baseURL: "/api",
  timeout: 15000,
  headers: { "Content-Type": "application/json" },
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    const msg =
      err.response?.data?.message || err.message || "Network error";
    return Promise.reject(new Error(msg));
  }
);

// ── Records ──────────────────────────────────────────────────────────────────
export const fetchRecords = (params = {}) =>
  api.get("/records", { params }).then((r) => r.data);

export const insertRecord = (data) =>
  api.post("/records", data).then((r) => r.data);

export const validateRecord = (data) =>
  api.post("/records/validate", data).then((r) => r.data);

export const bulkInsert = (records) =>
  api.post("/records/bulk", { records }).then((r) => r.data);

export const archiveRecord = (id) =>
  api.delete(`/records/${id}`).then((r) => r.data);

export const updateStatus = (id, status) =>
  api.patch(`/records/${id}/status`, { status }).then((r) => r.data);

// ── Analytics ────────────────────────────────────────────────────────────────
export const fetchStats = () =>
  api.get("/analytics/stats").then((r) => r.data);

export const fetchLogs = (params = {}) =>
  api.get("/analytics/logs", { params }).then((r) => r.data);

export const fetchTimeline = (days = 7) =>
  api.get("/analytics/timeline", { params: { days } }).then((r) => r.data);
