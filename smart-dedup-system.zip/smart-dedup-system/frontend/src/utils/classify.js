// frontend/src/utils/classify.js
export const classificationMeta = {
  unique:         { label: "Unique",         badge: "badge-green",  color: "#00ff88" },
  duplicate:      { label: "Duplicate",      badge: "badge-red",    color: "#ff4466" },
  false_positive: { label: "False Positive", badge: "badge-yellow", color: "#ffcc00" },
  near_duplicate: { label: "Near Duplicate", badge: "badge-purple", color: "#aa66ff" },
};

export const actionMeta = {
  inserted: { label: "Inserted", badge: "badge-green" },
  rejected: { label: "Rejected", badge: "badge-red" },
  flagged:  { label: "Flagged",  badge: "badge-yellow" },
};

export const statusMeta = {
  active:   { label: "Active",   badge: "badge-green" },
  flagged:  { label: "Flagged",  badge: "badge-yellow" },
  archived: { label: "Archived", badge: "badge-blue" },
};

export const confColor = (c) => {
  if (c >= 0.9) return "#ff4466";
  if (c >= 0.7) return "#aa66ff";
  if (c >= 0.5) return "#ffcc00";
  return "#00ff88";
};

export const fmt = {
  pct: (n) => `${(n * 100).toFixed(1)}%`,
  date: (d) =>
    new Date(d).toLocaleString("en-IN", {
      day: "2-digit", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit",
    }),
  short: (s, n = 28) =>
    s && s.length > n ? s.slice(0, n) + "…" : s || "—",
};
