// frontend/src/components/StatCard.jsx
export default function StatCard({ label, value, sub, color = "var(--accent-green)", icon: Icon }) {
  return (
    <div className="card" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <span style={{ fontSize: "0.72rem", fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>
          {label}
        </span>
        {Icon && <Icon size={16} color={color} />}
      </div>
      <div style={{ fontSize: "2rem", fontWeight: 700, color, fontFamily: "'JetBrains Mono', monospace", lineHeight: 1 }}>
        {value ?? "—"}
      </div>
      {sub && <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>{sub}</div>}
    </div>
  );
}
