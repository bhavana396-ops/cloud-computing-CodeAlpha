// frontend/src/components/Sidebar.jsx
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Database,
  PlusCircle,
  ScrollText,
  Settings,
  ShieldCheck,
} from "lucide-react";

const links = [
  { to: "/",        icon: LayoutDashboard, label: "Dashboard"    },
  { to: "/records", icon: Database,        label: "Records"      },
  { to: "/insert",  icon: PlusCircle,      label: "Insert Data"  },
  { to: "/logs",    icon: ScrollText,      label: "Audit Logs"   },
  { to: "/settings",icon: Settings,        label: "Settings"     },
];

export default function Sidebar() {
  return (
    <aside
      style={{
        width: 220,
        minHeight: "100vh",
        background: "var(--bg-secondary)",
        borderRight: "1px solid var(--border)",
        display: "flex",
        flexDirection: "column",
        padding: "0",
        flexShrink: 0,
      }}
    >
      {/* Logo */}
      <div
        style={{
          padding: "22px 20px 18px",
          borderBottom: "1px solid var(--border)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <ShieldCheck size={22} color="var(--accent-green)" />
          <div>
            <div
              style={{
                fontWeight: 700,
                fontSize: "0.95rem",
                color: "var(--text-primary)",
                letterSpacing: "-0.01em",
              }}
            >
              SmartDedup
            </div>
            <div style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>
              Data Integrity System
            </div>
          </div>
        </div>
      </div>

      {/* Live indicator */}
      <div
        style={{
          padding: "10px 20px",
          borderBottom: "1px solid var(--border)",
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <div className="pulse-dot" />
        <span style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>
          Engine Active
        </span>
      </div>

      {/* Nav links */}
      <nav style={{ padding: "10px 10px", flex: 1 }}>
        {links.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              "nav-item" + (isActive ? " active" : "")
            }
          >
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div
        style={{
          padding: "14px 20px",
          borderTop: "1px solid var(--border)",
          fontSize: "0.68rem",
          color: "var(--text-muted)",
        }}
      >
        v1.0.0 · MIT License
      </div>
    </aside>
  );
}
