// frontend/src/components/ResultBanner.jsx
import { classificationMeta, fmt } from "../utils/classify";
import { CheckCircle2, XCircle, AlertTriangle, Info } from "lucide-react";

const icons = {
  unique:         CheckCircle2,
  duplicate:      XCircle,
  false_positive: AlertTriangle,
  near_duplicate: Info,
};

export default function ResultBanner({ result, processingTimeMs }) {
  if (!result) return null;

  const meta = classificationMeta[result.classification] ?? classificationMeta.unique;
  const Icon = icons[result.classification] ?? CheckCircle2;
  const color = meta.color;

  return (
    <div
      style={{
        marginTop: "1.5rem",
        border: `1px solid ${color}44`,
        background: `${color}0d`,
        borderRadius: 10,
        padding: "1.25rem 1.5rem",
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Icon size={20} color={color} />
        <span style={{ fontWeight: 700, fontSize: "1rem", color }}>
          {meta.label}
        </span>
        <span style={{ marginLeft: "auto", fontSize: "0.72rem", color: "var(--text-muted)" }}>
          {processingTimeMs}ms
        </span>
      </div>

      {/* Confidence */}
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
          <span style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>Confidence</span>
          <span style={{ fontSize: "0.75rem", fontFamily: "'JetBrains Mono', monospace", color }}>
            {fmt.pct(result.confidence)}
          </span>
        </div>
        <div className="conf-bar-track">
          <div
            className="conf-bar-fill"
            style={{ width: `${result.confidence * 100}%`, background: color }}
          />
        </div>
      </div>

      {/* Field scores */}
      {result.details?.fieldScores && (
        <div>
          <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>
            Field-level similarity
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {Object.entries(result.details.fieldScores).map(([field, score]) => (
              <div key={field} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <span style={{ fontSize: "0.75rem", color: "var(--text-secondary)", width: 70 }}>{field}</span>
                <div className="conf-bar-track" style={{ flex: 1 }}>
                  <div
                    className="conf-bar-fill"
                    style={{ width: `${score * 100}%`, background: score > 0.85 ? "#ff4466" : score > 0.6 ? "#aa66ff" : "#00ff88" }}
                  />
                </div>
                <span style={{ fontSize: "0.72rem", fontFamily: "'JetBrains Mono', monospace", color: "var(--text-muted)", width: 40, textAlign: "right" }}>
                  {fmt.pct(score)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* False-positive reasons */}
      {result.details?.reasons && result.details.reasons.length > 0 && (
        <div style={{ fontSize: "0.75rem", color: "var(--accent-yellow)", background: "rgba(255,204,0,0.07)", borderRadius: 6, padding: "8px 12px" }}>
          {result.details.reasons.map((r, i) => <div key={i}>⚠ {r}</div>)}
        </div>
      )}

      {/* Method */}
      <div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>
        Detection method: <code style={{ color: "var(--text-secondary)" }}>{result.details?.method ?? "—"}</code>
        {" · "}Layer {result.details?.layer ?? "—"}
      </div>
    </div>
  );
}
