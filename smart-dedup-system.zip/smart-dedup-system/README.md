# 🛡️ Smart Dedup System

> **Intelligent Data Deduplication & Validation System**  
> Prevents redundant, duplicate, and false-positive entries from entering your cloud database using a 4-layer detection engine.

---

## 📐 Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    React Frontend                        │
│  Dashboard │ Records │ Insert │ Audit Logs │ Settings    │
└───────────────────────┬─────────────────────────────────┘
                        │ REST API
┌───────────────────────▼─────────────────────────────────┐
│                  Express.js Backend                      │
│                                                          │
│  POST /api/records  ──►  Dedup Engine (4 Layers)        │
│                           │                              │
│                    Layer 1: SHA-256 Fingerprint          │
│                    Layer 2: Fuzzy Similarity             │
│                             (Levenshtein + Jaro-Winkler) │
│                    Layer 3: Jaccard Token Overlap        │
│                    Layer 4: False-Positive Classifier    │
│                           │                              │
│                    ┌──────▼──────┐                       │
│                    │  DECISION   │                       │
│                    │ unique      │──► INSERT             │
│                    │ duplicate   │──► REJECT (409)       │
│                    │ near_dup    │──► INSERT + FLAG      │
│                    │ false_pos   │──► INSERT + REVIEW    │
│                    └─────────────┘                       │
└────────────────────────────────────────────────────────-─┘
                        │
┌───────────────────────▼─────────────────────────────────┐
│              MongoDB (Cloud or Local)                    │
│   DataRecord collection  +  DedupLog (audit trail)      │
└─────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** ≥ 18
- **MongoDB** (local or [Atlas](https://www.mongodb.com/atlas))

### 1. Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/smart-dedup-system.git
cd smart-dedup-system
npm run install:all
```

### 2. Configure Environment

```bash
cp backend/.env.example backend/.env
# Edit backend/.env — set MONGO_URI at minimum
```

### 3. Run Development Servers

```bash
npm run dev
# Backend  → http://localhost:5000
# Frontend → http://localhost:3000
```

---

## 🔍 Deduplication Engine

### Layer 1 — Fingerprint Hash
- Builds a **SHA-256 hash** from normalised key fields (email, phone, name)
- O(1) indexed lookup — zero false negatives for exact duplicates
- Enforced by MongoDB unique index as a database-level safety net

### Layer 2 — Fuzzy Field Similarity
- **Levenshtein** edit distance for emails and phones
- **Jaro-Winkler** for names (prefix-weighted, best for person names)
- Per-field scores combined into a weighted composite score

### Layer 3 — Semantic Token Overlap
- **Jaccard coefficient** on tokenised string values
- Catches paraphrase-level similarity across all string fields

### Layer 4 — False-Positive Classifier
- Rule-based heuristics applied *after* a similarity threshold is met
- Example rules:
  - Same name + very different email domain → **false positive**
  - Same email + different phone → **possible update, not duplicate**
  - Identical externalId → **hard duplicate**

### Classification Outcomes

| Classification   | Meaning                              | Action           |
|-----------------|--------------------------------------|-----------------|
| `unique`         | No match found                       | Insert           |
| `duplicate`      | High-confidence exact/near match     | Reject (409)     |
| `near_duplicate` | Probable duplicate, lower confidence | Insert + Flag    |
| `false_positive` | Classifier overrode match            | Insert + Flag    |

---

## 📡 API Reference

### `POST /api/records`
Insert a new record with full dedup validation.

**Body:**
```json
{
  "name": "Alice Johnson",
  "email": "alice@example.com",
  "phone": "+1-555-000-1234",
  "category": "customer",
  "externalId": "EXT-001",
  "payload": {}
}
```

**Response (unique — 201):**
```json
{
  "success": true,
  "message": "Record verified as unique and inserted",
  "data": { ... },
  "result": {
    "classification": "unique",
    "isDuplicate": false,
    "confidence": 0.12
  }
}
```

**Response (duplicate — 409):**
```json
{
  "success": false,
  "message": "Duplicate record detected — entry rejected",
  "result": {
    "classification": "duplicate",
    "confidence": 1.0,
    "matchedRecord": { ... }
  }
}
```

---

### `POST /api/records/validate`
**Dry-run** validation — checks without inserting.

---

### `POST /api/records/bulk`
Bulk insert up to **500 records** with per-record dedup.

**Body:** `{ "records": [ {...}, {...} ] }`

**Response (207):**
```json
{
  "summary": { "total": 5, "inserted": 3, "rejected": 1, "flagged": 1 },
  "inserted": [...],
  "rejected": [...],
  "flagged":  [...]
}
```

---

### `GET /api/records`
List records with optional filters: `?status=active&classification=unique&search=alice&page=1&limit=20`

### `DELETE /api/records/:id`
Archive a record (soft delete).

### `GET /api/analytics/stats`
Aggregated database and deduplication statistics.

### `GET /api/analytics/logs`
Paginated audit log with classification/action filters.

### `GET /api/analytics/timeline`
Daily activity breakdown for the last N days: `?days=7`

---

## ⚙️ Configuration

All settings live in `backend/.env`:

| Variable               | Default     | Description                                      |
|------------------------|-------------|--------------------------------------------------|
| `MONGO_URI`            | (required)  | MongoDB connection string                        |
| `SIMILARITY_THRESHOLD` | `0.85`      | Score above which a record is treated as duplicate |
| `FUZZY_MATCHING`       | `true`      | Enable Layers 2–4                                |
| `FINGERPRINT_FIELDS`   | `email,phone,name` | Fields used for SHA-256 fingerprint       |
| `PORT`                 | `5000`      | API server port                                  |
| `RATE_LIMIT_MAX`       | `100`       | Max requests per window                          |

---

## 🧪 Running Tests

```bash
cd backend
npm test
# Coverage report generated in /coverage
```

Tests cover:
- Fingerprint consistency & normalisation
- Exact-match detection
- Fuzzy/semantic similarity scoring
- False-positive classification
- Unique record pass-through

---

## 🗂️ Project Structure

```
smart-dedup-system/
├── backend/
│   ├── config/
│   │   └── database.js          # MongoDB connection
│   ├── middleware/
│   │   └── rateLimiter.js
│   ├── models/
│   │   ├── DataRecord.js        # Main data model
│   │   └── DedupLog.js          # Audit log model
│   ├── routes/
│   │   ├── records.js           # CRUD + dedup endpoints
│   │   └── analytics.js         # Stats + timeline
│   ├── utils/
│   │   ├── dedupEngine.js       # 4-layer dedup core ⭐
│   │   └── logger.js
│   ├── src/
│   │   └── server.js            # Express entry point
│   ├── __tests__/
│   │   └── dedupEngine.test.js
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/          # Sidebar, StatCard, ResultBanner
│   │   ├── pages/               # Dashboard, Records, InsertData, Logs, Settings
│   │   └── utils/               # api.js, classify.js
│   ├── index.html
│   └── vite.config.js
├── docs/
│   └── architecture.md
├── package.json                 # Root workspace
└── README.md
```

---

## 🚢 Deployment

### Backend (e.g. Render / Railway)
```bash
# Set env vars in your hosting dashboard, then:
npm run start
```

### Frontend (e.g. Vercel / Netlify)
```bash
cd frontend
npm run build
# Deploy the /dist folder
# Set VITE_API_URL if backend is on a different domain
```

### MongoDB Atlas
Replace `MONGO_URI` with your Atlas connection string — no other changes needed.

---

## 📄 License

MIT — free to use, modify, and distribute.
