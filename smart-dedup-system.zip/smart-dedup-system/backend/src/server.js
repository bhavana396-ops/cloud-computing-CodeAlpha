// backend/src/server.js
require("dotenv").config({ path: require("path").join(__dirname, "../.env") });

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const fs = require("fs");
const path = require("path");

const connectDB = require("../config/database");
const logger = require("../utils/logger");
const rateLimiter = require("../middleware/rateLimiter");
const recordsRouter = require("../routes/records");
const analyticsRouter = require("../routes/analytics");

// Ensure logs directory exists
const logsDir = path.join(__dirname, "../../logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

const app = express();

// ─── Security & Parsing ───────────────────────────────────────────────────────
app.use(helmet());
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    credentials: true,
  })
);
app.use(express.json({ limit: "5mb" }));
app.use(express.urlencoded({ extended: true }));

// ─── Logging ──────────────────────────────────────────────────────────────────
app.use(
  morgan("combined", {
    stream: { write: (msg) => logger.http(msg.trim()) },
  })
);

// ─── Rate Limiting ────────────────────────────────────────────────────────────
app.use("/api", rateLimiter);

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use("/api/records", recordsRouter);
app.use("/api/analytics", analyticsRouter);

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    service: "smart-dedup-system",
    timestamp: new Date().toISOString(),
  });
});

// ─── 404 ──────────────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route not found: ${req.originalUrl}` });
});

// ─── Global Error Handler ────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  logger.error(err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || "Internal server error",
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;

const start = async () => {
  await connectDB();
  app.listen(PORT, () => {
    logger.info(`🚀 Smart Dedup API running on port ${PORT}`);
    logger.info(`   Environment : ${process.env.NODE_ENV || "development"}`);
    logger.info(`   Threshold   : ${process.env.SIMILARITY_THRESHOLD || 0.85}`);
  });
};

start();

module.exports = app; // for testing
