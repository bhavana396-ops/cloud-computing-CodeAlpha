// backend/config/database.js
const mongoose = require("mongoose");
const logger = require("../utils/logger");

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 5000,
      maxPoolSize: 10,
    });
    logger.info(`MongoDB Connected: ${conn.connection.host}`);

    mongoose.connection.on("disconnected", () =>
      logger.warn("MongoDB disconnected")
    );
    mongoose.connection.on("reconnected", () =>
      logger.info("MongoDB reconnected")
    );
  } catch (err) {
    logger.error(`MongoDB connection error: ${err.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
