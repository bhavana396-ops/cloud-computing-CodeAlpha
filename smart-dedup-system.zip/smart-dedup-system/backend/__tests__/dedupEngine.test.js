// backend/__tests__/dedupEngine.test.js
const { buildFingerprint, runDedupCheck, fuzzyCompare } = require("../utils/dedupEngine");

process.env.FINGERPRINT_FIELDS = "email,phone,name";
process.env.SIMILARITY_THRESHOLD = "0.85";
process.env.FUZZY_MATCHING = "true";

const sample = {
  name: "Alice Johnson",
  email: "alice@example.com",
  phone: "+1-555-000-1234",
};

describe("buildFingerprint", () => {
  test("produces consistent hash for the same input", () => {
    expect(buildFingerprint(sample)).toBe(buildFingerprint({ ...sample }));
  });

  test("produces different hash for different email", () => {
    expect(buildFingerprint(sample)).not.toBe(
      buildFingerprint({ ...sample, email: "bob@example.com" })
    );
  });

  test("normalises case and whitespace", () => {
    const a = buildFingerprint({ name: "Alice Johnson", email: "ALICE@EXAMPLE.COM", phone: "15550001234" });
    const b = buildFingerprint({ name: "alice johnson", email: "alice@example.com", phone: "15550001234" });
    expect(a).toBe(b);
  });
});

describe("runDedupCheck — exact match", () => {
  test("flags exact duplicate via fingerprint", () => {
    const fingerprint = buildFingerprint(sample);
    const existing = [{ ...sample, _id: "abc123", fingerprint }];
    const result = runDedupCheck(sample, existing);
    expect(result.isDuplicate).toBe(true);
    expect(result.classification).toBe("duplicate");
    expect(result.confidence).toBe(1.0);
  });
});

describe("runDedupCheck — unique record", () => {
  test("allows unique record through", () => {
    const existing = [
      {
        name: "Bob Smith",
        email: "bob@example.com",
        phone: "+1-555-999-8888",
        fingerprint: buildFingerprint({ name: "Bob Smith", email: "bob@example.com", phone: "+1-555-999-8888" }),
      },
    ];
    const result = runDedupCheck(sample, existing);
    expect(result.isDuplicate).toBe(false);
    expect(result.classification).toBe("unique");
  });

  test("returns unique for empty candidate pool", () => {
    const result = runDedupCheck(sample, []);
    expect(result.isDuplicate).toBe(false);
    expect(result.classification).toBe("unique");
  });
});

describe("runDedupCheck — near duplicate", () => {
  test("detects near-duplicate by typo in name", () => {
    const typo = { ...sample, name: "Alise Johnson", fingerprint: "different" };
    const existing = [{ ...sample, _id: "x", fingerprint: buildFingerprint(sample) }];
    const result = runDedupCheck(typo, existing);
    // Should detect high similarity
    expect(result.confidence).toBeGreaterThan(0.7);
  });
});

describe("runDedupCheck — false positive", () => {
  test("classifies false positive when names match but emails diverge significantly", () => {
    const candidate = { name: "Alice Johnson", email: "alice@totallydifferentdomain.org", phone: "+1-555-000-1234" };
    const existing = [{ ...sample, _id: "y", fingerprint: buildFingerprint(sample) }];
    const result = runDedupCheck(candidate, existing, { threshold: 0.5 });
    // With very different email, classifier may flag as false positive
    expect(["false_positive", "near_duplicate", "unique"].includes(result.classification)).toBe(true);
  });
});

describe("fuzzyCompare", () => {
  test("returns score of 1 for identical records", () => {
    const { score } = fuzzyCompare(sample, sample);
    expect(score).toBeCloseTo(1, 1);
  });

  test("returns lower score for dissimilar records", () => {
    const other = { name: "Zara Patel", email: "zara@other.com", phone: "+44-20-0000-9999" };
    const { score } = fuzzyCompare(sample, other);
    expect(score).toBeLessThan(0.5);
  });
});
