// backend/utils/dedupEngine.js
/**
 * Smart Deduplication Engine
 * ─────────────────────────────────────────────────────────────────────────────
 * Identifies redundant and false-positive records using a multi-layer strategy:
 *   Layer 1 – Exact fingerprint hash (SHA-256 of normalised key fields)
 *   Layer 2 – Fuzzy field-level similarity (Levenshtein + Jaro-Winkler)
 *   Layer 3 – Semantic token overlap (Jaccard coefficient on tokenised strings)
 *   Layer 4 – False-positive classifier (heuristic rule set)
 * ─────────────────────────────────────────────────────────────────────────────
 */

const crypto = require("crypto");
const logger = require("./logger");

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Normalise a string: lowercase, trim, collapse whitespace */
const normalise = (str) =>
  String(str ?? "")
    .toLowerCase()
    .trim()
    .replace(/\s+/g, " ");

/** Strip all non-alphanumeric characters (used for phone/id normalisation) */
const stripNonAlpha = (str) => String(str ?? "").replace(/[^a-z0-9]/gi, "");

// ─── Layer 1: Fingerprint Hash ────────────────────────────────────────────────

/**
 * Build a deterministic SHA-256 fingerprint for a record.
 * Fields used are taken from the FINGERPRINT_FIELDS env var.
 * @param {Object} record
 * @returns {string} hex digest
 */
const buildFingerprint = (record) => {
  const fields = (process.env.FINGERPRINT_FIELDS || "email,phone,name").split(
    ","
  );

  const parts = fields.map((f) => {
    const val = record[f.trim()];
    if (f.trim() === "phone") return stripNonAlpha(val);
    return normalise(val);
  });

  return crypto.createHash("sha256").update(parts.join("|")).digest("hex");
};

// ─── Layer 2: Fuzzy String Similarity ─────────────────────────────────────────

/** Levenshtein edit distance */
const levenshtein = (a, b) => {
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] =
        a[i - 1] === b[j - 1]
          ? dp[i - 1][j - 1]
          : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
};

/** Normalised Levenshtein similarity (0–1) */
const levenshteinSimilarity = (a, b) => {
  if (!a && !b) return 1;
  if (!a || !b) return 0;
  const dist = levenshtein(a, b);
  return 1 - dist / Math.max(a.length, b.length);
};

/** Jaro similarity */
const jaro = (s1, s2) => {
  if (s1 === s2) return 1;
  const len1 = s1.length;
  const len2 = s2.length;
  const matchDist = Math.floor(Math.max(len1, len2) / 2) - 1;
  const s1Matches = new Array(len1).fill(false);
  const s2Matches = new Array(len2).fill(false);
  let matches = 0;
  let transpositions = 0;

  for (let i = 0; i < len1; i++) {
    const start = Math.max(0, i - matchDist);
    const end = Math.min(i + matchDist + 1, len2);
    for (let j = start; j < end; j++) {
      if (s2Matches[j] || s1[i] !== s2[j]) continue;
      s1Matches[i] = true;
      s2Matches[j] = true;
      matches++;
      break;
    }
  }
  if (matches === 0) return 0;

  let k = 0;
  for (let i = 0; i < len1; i++) {
    if (!s1Matches[i]) continue;
    while (!s2Matches[k]) k++;
    if (s1[i] !== s2[k]) transpositions++;
    k++;
  }
  return (
    (matches / len1 + matches / len2 + (matches - transpositions / 2) / matches) / 3
  );
};

/** Jaro-Winkler similarity */
const jaroWinkler = (s1, s2, p = 0.1) => {
  const j = jaro(s1, s2);
  let prefix = 0;
  for (let i = 0; i < Math.min(s1.length, s2.length, 4); i++) {
    if (s1[i] === s2[i]) prefix++;
    else break;
  }
  return j + prefix * p * (1 - j);
};

/**
 * Compare two records field-by-field and return a similarity score (0–1).
 * @param {Object} a
 * @param {Object} b
 * @returns {Object} { score, fieldScores }
 */
const fuzzyCompare = (a, b) => {
  const fields = (process.env.FINGERPRINT_FIELDS || "email,phone,name").split(
    ","
  );
  const fieldScores = {};
  let total = 0;

  for (const f of fields) {
    const va = normalise(a[f.trim()] ?? "");
    const vb = normalise(b[f.trim()] ?? "");

    // emails get exact + levenshtein
    if (f.trim() === "email") {
      fieldScores[f] = va === vb ? 1 : levenshteinSimilarity(va, vb) * 0.9;
    } else if (f.trim() === "phone") {
      const pa = stripNonAlpha(a[f.trim()] ?? "");
      const pb = stripNonAlpha(b[f.trim()] ?? "");
      fieldScores[f] = pa === pb ? 1 : levenshteinSimilarity(pa, pb) * 0.8;
    } else {
      // Jaro-Winkler is best for names
      fieldScores[f] = jaroWinkler(va, vb);
    }
    total += fieldScores[f];
  }

  return {
    score: total / fields.length,
    fieldScores,
  };
};

// ─── Layer 3: Jaccard Token Overlap ───────────────────────────────────────────

const tokenise = (str) =>
  new Set(normalise(str).split(/\s+/).filter(Boolean));

const jaccard = (setA, setB) => {
  if (setA.size === 0 && setB.size === 0) return 1;
  const intersection = new Set([...setA].filter((x) => setB.has(x)));
  const union = new Set([...setA, ...setB]);
  return intersection.size / union.size;
};

const semanticSimilarity = (a, b) => {
  const fields = Object.keys({ ...a, ...b }).filter(
    (k) => typeof a[k] === "string" || typeof b[k] === "string"
  );
  if (fields.length === 0) return 0;

  let total = 0;
  for (const f of fields) {
    total += jaccard(tokenise(a[f] ?? ""), tokenise(b[f] ?? ""));
  }
  return total / fields.length;
};

// ─── Layer 4: False-Positive Classifier ──────────────────────────────────────

/**
 * Heuristic rules that can down-grade a potential duplicate to a false positive.
 * Returns { isFalsePositive, reasons[] }
 */
const classifyFalsePositive = (candidate, existing) => {
  const reasons = [];

  // Rule 1: Same name, very different emails → likely different people
  const nameSim = jaroWinkler(
    normalise(candidate.name ?? ""),
    normalise(existing.name ?? "")
  );
  const emailSim = levenshteinSimilarity(
    normalise(candidate.email ?? ""),
    normalise(existing.email ?? "")
  );
  if (nameSim > 0.95 && emailSim < 0.4) {
    reasons.push("Same name but substantially different email domain");
  }

  // Rule 2: Exact email but mismatched phone (could be legitimate update)
  if (
    candidate.email &&
    existing.email &&
    normalise(candidate.email) === normalise(existing.email) &&
    candidate.phone &&
    existing.phone &&
    stripNonAlpha(candidate.phone) !== stripNonAlpha(existing.phone)
  ) {
    reasons.push("Matching email with different phone — possible record update");
  }

  // Rule 3: Both records have identical IDs → definitely duplicate
  if (
    candidate.externalId &&
    existing.externalId &&
    candidate.externalId === existing.externalId
  ) {
    reasons.push("Identical externalId — hard duplicate");
  }

  return {
    isFalsePositive: reasons.length > 0,
    reasons,
  };
};

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Run a full dedup check for an incoming record against a list of candidates.
 *
 * @param {Object}   incoming   - The new record to validate
 * @param {Object[]} candidates - Existing records to compare against
 * @param {Object}   opts
 * @param {number}   opts.threshold - Similarity threshold (default from env)
 * @param {boolean}  opts.fuzzy    - Enable fuzzy matching
 *
 * @returns {Object} {
 *   isDuplicate:      boolean,
 *   isFalsePositive:  boolean,
 *   confidence:       number (0–1),
 *   matchedRecord:    Object|null,
 *   classification:   'unique'|'duplicate'|'false_positive'|'near_duplicate',
 *   details:          Object
 * }
 */
const runDedupCheck = (incoming, candidates = [], opts = {}) => {
  const threshold = opts.threshold ?? parseFloat(process.env.SIMILARITY_THRESHOLD ?? "0.85");
  const fuzzyEnabled = opts.fuzzy ?? process.env.FUZZY_MATCHING !== "false";

  const incomingFp = buildFingerprint(incoming);

  // ── Layer 1: Exact hash match ──────────────────────────────────────────────
  const exactMatch = candidates.find((c) => c.fingerprint === incomingFp);
  if (exactMatch) {
    logger.debug(`Exact fingerprint match: ${incomingFp}`);
    return {
      isDuplicate: true,
      isFalsePositive: false,
      confidence: 1.0,
      matchedRecord: exactMatch,
      classification: "duplicate",
      details: { layer: 1, method: "fingerprint_hash", fingerprint: incomingFp },
    };
  }

  if (!fuzzyEnabled) {
    return {
      isDuplicate: false,
      isFalsePositive: false,
      confidence: 0,
      matchedRecord: null,
      classification: "unique",
      details: { layer: 1, method: "fingerprint_hash" },
    };
  }

  // ── Layer 2 & 3: Fuzzy + Semantic matching ─────────────────────────────────
  let bestScore = 0;
  let bestMatch = null;
  let bestDetails = {};

  for (const candidate of candidates) {
    const { score: fuzzyScore, fieldScores } = fuzzyCompare(incoming, candidate);
    const semScore = semanticSimilarity(incoming, candidate);
    const combined = fuzzyScore * 0.7 + semScore * 0.3;

    logger.debug(
      `Candidate ${candidate._id}: fuzzy=${fuzzyScore.toFixed(3)} sem=${semScore.toFixed(3)} combined=${combined.toFixed(3)}`
    );

    if (combined > bestScore) {
      bestScore = combined;
      bestMatch = candidate;
      bestDetails = { fuzzyScore, semScore, fieldScores };
    }
  }

  if (bestScore >= threshold && bestMatch) {
    // ── Layer 4: False-positive classification ──────────────────────────────
    const { isFalsePositive, reasons } = classifyFalsePositive(
      incoming,
      bestMatch
    );

    if (isFalsePositive) {
      return {
        isDuplicate: false,
        isFalsePositive: true,
        confidence: bestScore,
        matchedRecord: bestMatch,
        classification: "false_positive",
        details: {
          layer: 4,
          method: "false_positive_classifier",
          reasons,
          ...bestDetails,
        },
      };
    }

    const classification =
      bestScore >= 0.97 ? "duplicate" : "near_duplicate";

    return {
      isDuplicate: true,
      isFalsePositive: false,
      confidence: bestScore,
      matchedRecord: bestMatch,
      classification,
      details: {
        layer: bestScore >= 0.97 ? 2 : 3,
        method: "fuzzy_semantic",
        ...bestDetails,
      },
    };
  }

  return {
    isDuplicate: false,
    isFalsePositive: false,
    confidence: bestScore,
    matchedRecord: null,
    classification: "unique",
    details: { layer: 3, method: "fuzzy_semantic", bestScore, ...bestDetails },
  };
};

module.exports = { buildFingerprint, runDedupCheck, fuzzyCompare, normalise };
