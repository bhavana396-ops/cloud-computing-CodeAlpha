// backend/models/DedupLog.js
const mongoose = require("mongoose");

const dedupLogSchema = new mongoose.Schema(
  {
    incomingRecord: { type: mongoose.Schema.Types.Mixed, required: true },
    fingerprint: { type: String, required: true },
    classification: {
      type: String,
      enum: ["unique", "duplicate", "false_positive", "near_duplicate"],
      required: true,
    },
    isDuplicate: { type: Boolean, required: true },
    isFalsePositive: { type: Boolean, default: false },
    confidence: { type: Number, min: 0, max: 1 },
    matchedRecordId: { type: mongoose.Schema.Types.ObjectId, ref: "DataRecord" },
    details: { type: mongoose.Schema.Types.Mixed },
    action: {
      type: String,
      enum: ["inserted", "rejected", "flagged"],
      required: true,
    },
    processingTimeMs: { type: Number },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

dedupLogSchema.index({ classification: 1 });
dedupLogSchema.index({ isDuplicate: 1 });
dedupLogSchema.index({ createdAt: -1 });

module.exports = mongoose.model("DedupLog", dedupLogSchema);
