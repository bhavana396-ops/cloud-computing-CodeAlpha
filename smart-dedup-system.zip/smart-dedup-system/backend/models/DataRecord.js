// backend/models/DataRecord.js
const mongoose = require("mongoose");

const dataRecordSchema = new mongoose.Schema(
  {
    // ── Core payload ────────────────────────────────────────────────────────
    name: { type: String, trim: true },
    email: { type: String, trim: true, lowercase: true },
    phone: { type: String, trim: true },
    externalId: { type: String, trim: true },
    category: { type: String, trim: true, default: "general" },
    payload: { type: mongoose.Schema.Types.Mixed, default: {} },

    // ── Dedup metadata ──────────────────────────────────────────────────────
    fingerprint: {
      type: String,
      required: true,
      index: true,
    },

    status: {
      type: String,
      enum: ["active", "archived", "flagged"],
      default: "active",
    },

    // Dedup analysis result stored with the record
    dedupMeta: {
      confidence: { type: Number, default: 1 },
      classification: {
        type: String,
        enum: ["unique", "duplicate", "false_positive", "near_duplicate"],
        default: "unique",
      },
      checkedAt: { type: Date, default: Date.now },
    },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Compound index for fast lookup on email + phone
dataRecordSchema.index({ email: 1, phone: 1 });
dataRecordSchema.index({ fingerprint: 1 }, { unique: true });
dataRecordSchema.index({ createdAt: -1 });
dataRecordSchema.index({ status: 1 });

module.exports = mongoose.model("DataRecord", dataRecordSchema);
