// backend/routes/analytics.js
const express = require("express");
const router = express.Router();
const DataRecord = require("../models/DataRecord");
const DedupLog = require("../models/DedupLog");
const logger = require("../utils/logger");

// ─── GET /api/analytics/stats ─────────────────────────────────────────────────
router.get("/stats", async (req, res) => {
  try {
    const [
      totalRecords,
      activeRecords,
      flaggedRecords,
      archivedRecords,
      totalLogs,
      duplicatesRejected,
      falsePositives,
      nearDuplicates,
      recentLogs,
    ] = await Promise.all([
      DataRecord.countDocuments(),
      DataRecord.countDocuments({ status: "active" }),
      DataRecord.countDocuments({ status: "flagged" }),
      DataRecord.countDocuments({ status: "archived" }),
      DedupLog.countDocuments(),
      DedupLog.countDocuments({ isDuplicate: true }),
      DedupLog.countDocuments({ isFalsePositive: true }),
      DedupLog.countDocuments({ classification: "near_duplicate" }),
      DedupLog.find()
        .sort({ createdAt: -1 })
        .limit(10)
        .lean(),
    ]);

    const deduplicationRate =
      totalLogs > 0
        ? ((duplicatesRejected / totalLogs) * 100).toFixed(1)
        : "0.0";

    res.json({
      success: true,
      data: {
        database: {
          totalRecords,
          activeRecords,
          flaggedRecords,
          archivedRecords,
        },
        deduplication: {
          totalChecks: totalLogs,
          duplicatesRejected,
          falsePositives,
          nearDuplicates,
          uniqueInserted: totalLogs - duplicatesRejected,
          deduplicationRate: `${deduplicationRate}%`,
        },
        recentActivity: recentLogs,
      },
    });
  } catch (err) {
    logger.error("GET /analytics/stats error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// ─── GET /api/analytics/logs ──────────────────────────────────────────────────
router.get("/logs", async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;
    const filter = {};
    if (req.query.classification)
      filter.classification = req.query.classification;
    if (req.query.action) filter.action = req.query.action;

    const [logs, total] = await Promise.all([
      DedupLog.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      DedupLog.countDocuments(filter),
    ]);

    res.json({
      success: true,
      data: logs,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch (err) {
    logger.error("GET /analytics/logs error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// ─── GET /api/analytics/timeline ─────────────────────────────────────────────
router.get("/timeline", async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 7;
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const pipeline = [
      { $match: { createdAt: { $gte: since } } },
      {
        $group: {
          _id: {
            date: {
              $dateToString: { format: "%Y-%m-%d", date: "$createdAt" },
            },
            action: "$action",
          },
          count: { $sum: 1 },
        },
      },
      { $sort: { "_id.date": 1 } },
    ];

    const raw = await DedupLog.aggregate(pipeline);

    // Reshape into { date, inserted, rejected, flagged }
    const map = {};
    for (const entry of raw) {
      const d = entry._id.date;
      if (!map[d]) map[d] = { date: d, inserted: 0, rejected: 0, flagged: 0 };
      map[d][entry._id.action] = entry.count;
    }

    res.json({
      success: true,
      data: Object.values(map),
    });
  } catch (err) {
    logger.error("GET /analytics/timeline error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

module.exports = router;
