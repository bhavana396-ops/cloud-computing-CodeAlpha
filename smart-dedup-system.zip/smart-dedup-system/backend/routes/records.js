// backend/routes/records.js
const express = require("express");
const router = express.Router();
const { body, query, validationResult } = require("express-validator");
const DataRecord = require("../models/DataRecord");
const DedupLog = require("../models/DedupLog");
const { buildFingerprint, runDedupCheck } = require("../utils/dedupEngine");
const logger = require("../utils/logger");

// ─── Validation middleware ────────────────────────────────────────────────────
const validateRecord = [
  body("name").optional().isString().trim().isLength({ min: 1, max: 200 }),
  body("email").optional().isEmail().normalizeEmail(),
  body("phone").optional().isString().trim(),
  body("category").optional().isString().trim(),
  body("payload").optional().isObject(),
];

const handleValidation = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: "Validation failed",
      errors: errors.array(),
    });
  }
  next();
};

// ─── GET /api/records ─────────────────────────────────────────────────────────
router.get(
  "/",
  [
    query("page").optional().isInt({ min: 1 }),
    query("limit").optional().isInt({ min: 1, max: 100 }),
    query("status").optional().isIn(["active", "archived", "flagged"]),
    query("classification")
      .optional()
      .isIn(["unique", "duplicate", "false_positive", "near_duplicate"]),
  ],
  async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 20;
      const skip = (page - 1) * limit;

      const filter = {};
      if (req.query.status) filter.status = req.query.status;
      if (req.query.classification)
        filter["dedupMeta.classification"] = req.query.classification;
      if (req.query.search) {
        const s = req.query.search;
        filter.$or = [
          { name: new RegExp(s, "i") },
          { email: new RegExp(s, "i") },
          { phone: new RegExp(s, "i") },
        ];
      }

      const [records, total] = await Promise.all([
        DataRecord.find(filter)
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(limit)
          .lean(),
        DataRecord.countDocuments(filter),
      ]);

      res.json({
        success: true,
        data: records,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (err) {
      logger.error("GET /records error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ─── POST /api/records ────────────────────────────────────────────────────────
// Core endpoint: validate → dedup → insert or reject
router.post("/", validateRecord, handleValidation, async (req, res) => {
  const startTime = Date.now();

  try {
    const incoming = req.body;

    // 1. Build fingerprint
    const fingerprint = buildFingerprint(incoming);

    // 2. Fetch candidate pool: records that share at least one key field
    //    to avoid scanning the entire collection on every insert.
    const candidateFilter = { status: "active" };
    if (incoming.email)
      candidateFilter.$or = [
        { email: incoming.email },
        { name: new RegExp(incoming.name ?? "", "i") },
      ];

    const candidates = await DataRecord.find(candidateFilter)
      .limit(200)
      .lean();

    // 3. Run multi-layer dedup check
    const result = runDedupCheck(incoming, candidates, {
      threshold: req.body.threshold,
    });

    const processingTimeMs = Date.now() - startTime;

    // 4. Log the outcome (audit trail)
    let action;
    if (result.isDuplicate) {
      action = "rejected";
    } else if (result.isFalsePositive) {
      action = "flagged";
    } else {
      action = "inserted";
    }

    await DedupLog.create({
      incomingRecord: incoming,
      fingerprint,
      classification: result.classification,
      isDuplicate: result.isDuplicate,
      isFalsePositive: result.isFalsePositive,
      confidence: result.confidence,
      matchedRecordId: result.matchedRecord?._id ?? null,
      details: result.details,
      action,
      processingTimeMs,
    });

    // 5. If duplicate → reject
    if (result.isDuplicate) {
      return res.status(409).json({
        success: false,
        message: "Duplicate record detected — entry rejected",
        result,
        processingTimeMs,
      });
    }

    // 6. If false positive → insert but flag
    const newRecord = await DataRecord.create({
      ...incoming,
      fingerprint,
      status: result.isFalsePositive ? "flagged" : "active",
      dedupMeta: {
        confidence: result.confidence,
        classification: result.classification,
        checkedAt: new Date(),
      },
    });

    return res.status(201).json({
      success: true,
      message: result.isFalsePositive
        ? "Record flagged as possible false positive — inserted for review"
        : "Record verified as unique and inserted",
      data: newRecord,
      result,
      processingTimeMs,
    });
  } catch (err) {
    if (err.code === 11000) {
      // Mongoose unique index violation (race condition)
      return res.status(409).json({
        success: false,
        message: "Duplicate fingerprint — concurrent insert rejected",
      });
    }
    logger.error("POST /records error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// ─── POST /api/records/validate ───────────────────────────────────────────────
// Dry-run: check without inserting
router.post(
  "/validate",
  validateRecord,
  handleValidation,
  async (req, res) => {
    const startTime = Date.now();
    try {
      const incoming = req.body;
      const fingerprint = buildFingerprint(incoming);

      const candidateFilter = { status: "active" };
      if (incoming.email)
        candidateFilter.$or = [
          { email: incoming.email },
          { name: new RegExp(incoming.name ?? "", "i") },
        ];

      const candidates = await DataRecord.find(candidateFilter)
        .limit(200)
        .lean();

      const result = runDedupCheck(incoming, candidates);
      const processingTimeMs = Date.now() - startTime;

      res.json({
        success: true,
        message: "Validation complete (dry-run, no data written)",
        fingerprint,
        result,
        processingTimeMs,
      });
    } catch (err) {
      logger.error("POST /records/validate error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ─── POST /api/records/bulk ───────────────────────────────────────────────────
// Bulk insert with per-record dedup
router.post("/bulk", async (req, res) => {
  try {
    const { records } = req.body;
    if (!Array.isArray(records) || records.length === 0) {
      return res
        .status(400)
        .json({ success: false, message: "records[] array required" });
    }
    if (records.length > 500) {
      return res
        .status(400)
        .json({ success: false, message: "Max 500 records per bulk request" });
    }

    const results = {
      inserted: [],
      rejected: [],
      flagged: [],
      summary: { total: records.length, inserted: 0, rejected: 0, flagged: 0 },
    };

    // Process sequentially so each inserted record can block subsequent ones
    const inserted = [];
    for (const rec of records) {
      const fingerprint = buildFingerprint(rec);
      const candidates = [
        ...(await DataRecord.find({ status: "active" }).limit(200).lean()),
        ...inserted,
      ];

      const result = runDedupCheck(rec, candidates);

      if (result.isDuplicate) {
        results.rejected.push({ record: rec, result });
        results.summary.rejected++;
      } else {
        const newRec = await DataRecord.create({
          ...rec,
          fingerprint,
          status: result.isFalsePositive ? "flagged" : "active",
          dedupMeta: {
            confidence: result.confidence,
            classification: result.classification,
            checkedAt: new Date(),
          },
        });
        inserted.push({ ...newRec.toObject(), fingerprint });
        if (result.isFalsePositive) {
          results.flagged.push({ record: newRec, result });
          results.summary.flagged++;
        } else {
          results.inserted.push({ record: newRec, result });
          results.summary.inserted++;
        }
      }
    }

    res.status(207).json({ success: true, ...results });
  } catch (err) {
    logger.error("POST /records/bulk error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// ─── DELETE /api/records/:id ──────────────────────────────────────────────────
router.delete("/:id", async (req, res) => {
  try {
    const record = await DataRecord.findByIdAndUpdate(
      req.params.id,
      { status: "archived" },
      { new: true }
    );
    if (!record)
      return res
        .status(404)
        .json({ success: false, message: "Record not found" });

    res.json({ success: true, message: "Record archived", data: record });
  } catch (err) {
    logger.error("DELETE /records/:id error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// ─── PATCH /api/records/:id/status ───────────────────────────────────────────
router.patch("/:id/status", async (req, res) => {
  try {
    const { status } = req.body;
    if (!["active", "archived", "flagged"].includes(status)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid status" });
    }
    const record = await DataRecord.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );
    if (!record)
      return res
        .status(404)
        .json({ success: false, message: "Record not found" });

    res.json({ success: true, data: record });
  } catch (err) {
    logger.error("PATCH /records/:id/status error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

module.exports = router;
