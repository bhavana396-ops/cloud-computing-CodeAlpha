# Architecture — Smart Dedup System

## Data Flow

```
Client Request (POST /api/records)
          │
          ▼
    Rate Limiter ──(429)──► Error
          │
          ▼
    Input Validation (express-validator)
          │ fail
          ▼
       422 Error

          │ pass
          ▼
    buildFingerprint()
    SHA-256( normalise(email) | stripNonAlpha(phone) | normalise(name) )
          │
          ▼
    Fetch Candidate Pool from MongoDB
    (records sharing email or name, up to 200)
          │
          ▼
    ┌─────────────────────────────────┐
    │        runDedupCheck()          │
    │                                 │
    │  L1: fingerprint === existing?  │──YES──► DUPLICATE (conf=1.0)
    │            │ NO                 │
    │  L2+L3: fuzzy + semantic score  │
    │       score >= threshold?       │──NO───► UNIQUE
    │            │ YES                │
    │  L4: false positive rules?      │──YES──► FALSE_POSITIVE
    │            │ NO                 │
    │       score >= 0.97?            │──YES──► DUPLICATE
    │            │ NO                 │
    │       NEAR_DUPLICATE            │
    └─────────────────────────────────┘
          │
          ▼
    Log to DedupLog (audit trail)
          │
    ┌─────┴──────┐
    │            │
  UNIQUE     DUPLICATE
  INSERT      REJECT
   201         409
```

## Index Strategy (MongoDB)

| Collection  | Index                         | Purpose                          |
|-------------|-------------------------------|----------------------------------|
| DataRecord  | `fingerprint` (unique)        | Layer 1 exact match + race guard |
| DataRecord  | `email + phone` (compound)    | Candidate pool fetch             |
| DataRecord  | `status`                      | Filter queries                   |
| DataRecord  | `createdAt` desc              | Pagination                       |
| DedupLog    | `classification`              | Analytics filtering              |
| DedupLog    | `createdAt` desc              | Recent activity                  |

## Similarity Algorithms

### Levenshtein Distance
Used for emails and phone numbers.
`similarity = 1 - editDistance / max(len_a, len_b)`

### Jaro-Winkler
Used for names — gives extra weight to common prefixes.
Best algorithm for person name fuzzy matching.

### Jaccard Coefficient
`J(A,B) = |A ∩ B| / |A ∪ B|`
Applied to token sets of all string fields combined.

### Composite Score
`score = fuzzyScore * 0.7 + semanticScore * 0.3`
