/**
 * Booking API Tests — Pricing Integrity & Seat Locking
 */

const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../backend/server');
const { Route, Bus } = require('../backend/models/Bus');

let token = '';
let testBusId = '';
let testRouteId = '';

beforeAll(async () => {
  // Register and login
  const reg = await request(app).post('/api/auth/register').send({
    name: 'Booking Tester',
    email: `booking_${Date.now()}@test.com`,
    phone: '9123456780',
    password: 'Booking@123',
  });
  token = reg.body.accessToken;

  // Create test route & bus
  const route = await Route.create({
    routeNumber: `TEST-${Date.now()}`,
    name: 'Test City A → Test City B',
    source: 'City A',
    destination: 'City B',
    baseFare: 2,
    totalDistance: 100,
    stops: [
      { name: 'City A', distanceFromSource: 0, estimatedTime: 0 },
      { name: 'City B', distanceFromSource: 100, estimatedTime: 120 },
    ],
  });
  testRouteId = route._id;

  const tomorrow = new Date(Date.now() + 86400000);
  const bus = await Bus.create({
    busNumber: `TEST-BUS-${Date.now()}`,
    route: route._id,
    type: 'ordinary',
    totalSeats: 50,
    availableSeats: 50,
    fareMultiplier: 1.0,
    departureTime: tomorrow,
    arrivalTime: new Date(tomorrow.getTime() + 7200000),
    currentStatus: 'scheduled',
  });
  testBusId = bus._id.toString();
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
});

describe('GET /api/bookings/search', () => {
  it('should return search results for valid query', async () => {
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    const res = await request(app)
      .get(`/api/bookings/search?source=City+A&destination=City+B&date=${tomorrow}&passengers=1`)
      .set('Authorization', `Bearer ${token}`);
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body.data)).toBe(true);
  });

  it('should require auth', async () => {
    const res = await request(app).get('/api/bookings/search?source=a&destination=b&date=2025-01-01&passengers=1');
    expect(res.statusCode).toBe(401);
  });
});

describe('POST /api/bookings/initiate', () => {
  it('should initiate a booking with server-side fare', async () => {
    const tomorrow = new Date(Date.now() + 86400000).toISOString();
    const res = await request(app)
      .post('/api/bookings/initiate')
      .set('Authorization', `Bearer ${token}`)
      .send({
        busId: testBusId,
        boardingStop: 'City A',
        alightingStop: 'City B',
        journeyDate: tomorrow,
        seatNumbers: ['B1'],
        passengerCount: 1,
      });
    expect(res.statusCode).toBe(201);
    expect(res.body.finalAmount).toBeGreaterThan(0);
    expect(res.body.ticketId).toBeDefined();
    // Fare must be server-calculated; cannot be zero or negative
    expect(res.body.finalAmount).toBeGreaterThan(res.body.breakdown.totalFare * 0.99);
  });
});
