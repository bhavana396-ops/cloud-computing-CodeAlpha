# 📡 BusPass Cloud — API Reference

Base URL: `http://localhost:5000/api` (dev) | `https://yourdomain.com/api` (prod)

All protected routes require: `Authorization: Bearer <access_token>`

---

## 🔐 Auth

### POST /auth/register
Register a new user.
```json
{ "name": "Rahul", "email": "r@x.com", "phone": "9876543210", "password": "Pass@123" }
```
**Response 201:** `{ success, accessToken, user }`

### POST /auth/login
```json
{ "email": "r@x.com", "password": "Pass@123" }
```
**Response 200:** `{ success, accessToken, user }`

### POST /auth/refresh
```json
{ "refreshToken": "..." }
```

### POST /auth/logout *(protected)*
Invalidates refresh token.

### GET /auth/me *(protected)*
Returns current user info.

---

## 🎟️ Bookings

### GET /bookings/search *(protected)*
```
?source=Mumbai&destination=Pune&date=2025-01-15&passengers=2
```
Returns available buses with server-calculated fares.

### POST /bookings/initiate *(protected)*
Locks seats (10 min) and creates pending ticket.
```json
{
  "busId": "...",
  "boardingStop": "Mumbai",
  "alightingStop": "Pune",
  "journeyDate": "2025-01-15T08:30:00Z",
  "seatNumbers": ["A1", "A2"],
  "passengerCount": 2
}
```
**Response 201:** `{ ticketId, finalAmount, breakdown, expiresIn }`

### POST /bookings/confirm *(protected)*
Call after successful payment.
```json
{ "ticketId": "TKT-...", "paymentId": "PAY_...", "paymentMethod": "upi" }
```
**Response 200:** `{ ticket: { ticketId, qrCode, ... } }`

### DELETE /bookings/:ticketId *(protected)*
Cancel a ticket. Returns refund amount based on timing.

---

## 📋 Tickets

### GET /tickets *(protected)*
`?status=confirmed&page=1&limit=10`

### GET /tickets/:ticketId *(protected)*

### POST /tickets/:ticketId/verify *(conductor/admin only)*
Verifies QR code integrity and marks ticket as used.

---

## 👨‍💼 Admin *(admin role required)*

### GET /admin/stats
Returns system-wide counts and revenue.

### POST /admin/routes
Create a new bus route.

### POST /admin/buses
Add a bus to a route.

### PATCH /admin/buses/:id/status
Update bus status: `scheduled | boarding | departed | arrived | cancelled`

### GET /admin/users
List all registered users.

---

## ⚠️ Error Codes

| Code | Meaning |
|------|---------|
| 400 | Validation error |
| 401 | Unauthorized / token expired |
| 403 | Forbidden (insufficient role) |
| 404 | Resource not found |
| 409 | Conflict (duplicate / seat locked) |
| 429 | Rate limit exceeded |
| 500 | Internal server error |
