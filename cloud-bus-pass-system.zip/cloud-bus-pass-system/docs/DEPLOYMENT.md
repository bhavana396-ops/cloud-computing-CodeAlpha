# ☁️ Deployment Guide — AWS

## Prerequisites
- AWS account with IAM user having EC2, ECR, ALB, Auto Scaling, CloudFront permissions
- MongoDB Atlas cluster (free tier works)
- Domain name (optional)

---

## Step 1 — MongoDB Atlas Setup
1. Create account at [mongodb.com/cloud/atlas](https://mongodb.com/cloud/atlas)
2. Create a free M0 cluster
3. Create DB user and whitelist `0.0.0.0/0` (or your EC2 IP range)
4. Copy the connection string → set as `MONGO_URI` in your environment

---

## Step 2 — AWS ECR (Container Registry)
```bash
# Create repository
aws ecr create-repository --repository-name buspass-app --region ap-south-1

# Build and push
aws ecr get-login-password | docker login --username AWS --password-stdin <account>.dkr.ecr.ap-south-1.amazonaws.com
docker build -t buspass-app .
docker tag buspass-app:latest <account>.dkr.ecr.ap-south-1.amazonaws.com/buspass-app:latest
docker push <account>.dkr.ecr.ap-south-1.amazonaws.com/buspass-app:latest
```

---

## Step 3 — EC2 Auto Scaling Group
1. Create Launch Template:
   - AMI: Amazon Linux 2023
   - Instance type: t3.micro (free tier)
   - User data script:
   ```bash
   #!/bin/bash
   yum update -y
   amazon-linux-extras install docker -y
   systemctl start docker
   aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin <ecr-url>
   docker pull <ecr-url>/buspass-app:latest
   docker run -d -p 5000:5000 --env-file /etc/buspass.env <ecr-url>/buspass-app:latest
   ```

2. Create Auto Scaling Group:
   - Min: 1, Desired: 2, Max: 10
   - Scaling policy: Target tracking, CPU > 60%

---

## Step 4 — Application Load Balancer
1. Create ALB in public subnets
2. Target group: port 5000, health check `/health`
3. Listener: HTTP:80 → redirect to HTTPS:443
4. Attach Auto Scaling Group to target group

---

## Step 5 — CloudFront CDN
1. Create distribution → origin: ALB DNS name
2. Cache static assets (`/css/*`, `/js/*`, `/images/*`) for 24 hours
3. Attach SSL certificate via ACM (free)

---

## Step 6 — GitHub Actions Secrets
Add these secrets to your GitHub repo Settings → Secrets:
```
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
CLOUDFRONT_DISTRIBUTION_ID
APP_DOMAIN
```

---

## Step 7 — Environment Variables on EC2
Create `/etc/buspass.env`:
```
NODE_ENV=production
MONGO_URI=mongodb+srv://...
REDIS_HOST=<elasticache-endpoint>
JWT_SECRET=<strong-random-string>
JWT_REFRESH_SECRET=<strong-random-string>
TICKET_SECRET=<strong-random-string>
```

---

## Architecture Summary
```
Internet → Route 53 (DNS)
         → CloudFront CDN (SSL termination + caching)
         → Application Load Balancer
         → EC2 Auto Scaling Group (1-10 instances)
         → Redis ElastiCache (session + locks)
         → MongoDB Atlas (multi-region)
         → SNS/SES (email notifications)
```
