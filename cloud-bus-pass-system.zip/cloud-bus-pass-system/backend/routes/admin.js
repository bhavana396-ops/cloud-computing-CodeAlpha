const express = require("express");
const User = require("../models/User");
const Ticket = require("../models/Ticket");
const { Bus, Route } = require("../models/Bus");
const { authMiddleware, adminMiddleware } = require("../middleware/auth");

const router = express.Router();
router.use(authMiddleware, adminMiddleware);

// GET /api/admin/stats — dashboard metrics
router.get("/stats", async (req, res, next) => {
  try {
    const [totalUsers, totalTickets, totalRevenue, activeRoutes, activeBuses] = await Promise.all([
      User.countDocuments({ role: "passenger" }),
      Ticket.countDocuments({ paymentStatus: "paid" }),
      Ticket.aggregate([
        { $match: { paymentStatus: "paid" } },
        { $group: { _id: null, total: { $sum: "$finalAmount" } } },
      ]),
      Route.countDocuments({ isActive: true }),
      Bus.countDocuments({ isActive: true, currentStatus: { $ne: "cancelled" } }),
    ]);

    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const todayTickets = await Ticket.countDocuments({ createdAt: { $gte: todayStart }, paymentStatus: "paid" });

    res.json({
      success: true,
      data: {
        totalUsers,
        totalTickets,
        totalRevenue: totalRevenue[0]?.total || 0,
        activeRoutes,
        activeBuses,
        todayTickets,
      },
    });
  } catch (err) {
    next(err);
  }
});

// POST /api/admin/routes — create route
router.post("/routes", async (req, res, next) => {
  try {
    const route = await Route.create(req.body);
    res.status(201).json({ success: true, data: route });
  } catch (err) {
    next(err);
  }
});

// POST /api/admin/buses — add bus
router.post("/buses", async (req, res, next) => {
  try {
    const bus = await Bus.create({ ...req.body, availableSeats: req.body.totalSeats });
    res.status(201).json({ success: true, data: bus });
  } catch (err) {
    next(err);
  }
});

// PATCH /api/admin/buses/:id/status — update bus status
router.patch("/buses/:id/status", async (req, res, next) => {
  try {
    const bus = await Bus.findByIdAndUpdate(req.params.id, { currentStatus: req.body.status }, { new: true });
    res.json({ success: true, data: bus });
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/users — list all users
router.get("/users", async (req, res, next) => {
  try {
    const users = await User.find().select("-password -refreshToken").sort({ createdAt: -1 }).limit(100);
    res.json({ success: true, data: users });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
