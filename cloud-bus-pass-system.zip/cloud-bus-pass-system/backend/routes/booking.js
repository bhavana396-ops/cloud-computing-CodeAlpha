const express = require("express");
const { body, query, validationResult } = require("express-validator");
const QRCode = require("qrcode");
const Ticket = require("../models/Ticket");
const { Bus, Route } = require("../models/Bus");
const { authMiddleware } = require("../middleware/auth");
const { getRedis } = require("../config/redis");
const logger = require("../config/logger");

const router = express.Router();

// ─── Helper: Server-side fare calculation (prevents pricing manipulation) ─────
const calculateFare = (route, busType, boardingStop, alightingStop) => {
  const stops = route.stops;
  const from = stops.find((s) => s.name === boardingStop);
  const to = stops.find((s) => s.name === alightingStop);

  if (!from || !to) throw new Error("Invalid boarding or alighting stop");
  const distance = Math.abs(to.distanceFromSource - from.distanceFromSource);

  const multipliers = { ordinary: 1.0, express: 1.3, ac: 1.8, luxury: 2.2 };
  const multiplier = multipliers[busType] || 1.0;

  const baseFare = route.baseFare * distance * multiplier;
  const farePerSeat = Math.ceil(baseFare / 5) * 5; // round to ₹5
  return { farePerSeat, distance };
};

// ─── GET /api/bookings/search ─────────────────────────────────────────────────
router.get(
  "/search",
  [
    query("source").notEmpty(),
    query("destination").notEmpty(),
    query("date").isISO8601(),
    query("passengers").isInt({ min: 1, max: 6 }),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty())
      return res.status(400).json({ success: false, errors: errors.array() });

    try {
      const { source, destination, date, passengers } = req.query;
      const redis = getRedis();

      // Cache results for 2 minutes to reduce DB load during high traffic
      const cacheKey = `search:${source}:${destination}:${date}`;
      const cached = await redis.get(cacheKey).catch(() => null);
      if (cached) {
        return res.json({ success: true, data: JSON.parse(cached), fromCache: true });
      }

      const travelDate = new Date(date);
      const nextDay = new Date(travelDate);
      nextDay.setDate(nextDay.getDate() + 1);

      const routes = await Route.find({
        source: new RegExp(source, "i"),
        destination: new RegExp(destination, "i"),
        isActive: true,
      });

      if (!routes.length)
        return res.json({ success: true, data: [], message: "No routes found" });

      const buses = await Bus.find({
        route: { $in: routes.map((r) => r._id) },
        departureTime: { $gte: travelDate, $lt: nextDay },
        availableSeats: { $gte: parseInt(passengers) },
        currentStatus: { $in: ["scheduled", "boarding"] },
        isActive: true,
      }).populate("route");

      const results = buses.map((bus) => {
        const { farePerSeat } = calculateFare(
          bus.route,
          bus.type,
          bus.route.source,
          bus.route.destination
        );
        return {
          busId: bus._id,
          busNumber: bus.busNumber,
          type: bus.type,
          route: bus.route.name,
          source: bus.route.source,
          destination: bus.route.destination,
          departureTime: bus.departureTime,
          arrivalTime: bus.arrivalTime,
          availableSeats: bus.availableSeats,
          farePerSeat,
          totalFare: farePerSeat * parseInt(passengers),
          stops: bus.route.stops,
        };
      });

      await redis.setex(cacheKey, 120, JSON.stringify(results)).catch(() => {});
      res.json({ success: true, data: results });
    } catch (err) {
      next(err);
    }
  }
);

// ─── POST /api/bookings/initiate ──────────────────────────────────────────────
// Locks seats in Redis for 10 minutes while user completes payment
router.post(
  "/initiate",
  authMiddleware,
  [
    body("busId").notEmpty(),
    body("boardingStop").notEmpty(),
    body("alightingStop").notEmpty(),
    body("journeyDate").isISO8601(),
    body("seatNumbers").isArray({ min: 1, max: 6 }),
    body("passengerCount").isInt({ min: 1, max: 6 }),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty())
      return res.status(400).json({ success: false, errors: errors.array() });

    try {
      const { busId, boardingStop, alightingStop, journeyDate, seatNumbers, passengerCount } = req.body;
      const redis = getRedis();

      const bus = await Bus.findById(busId).populate("route");
      if (!bus || !bus.isActive)
        return res.status(404).json({ success: false, message: "Bus not found" });

      if (bus.availableSeats < passengerCount)
        return res.status(409).json({ success: false, message: "Not enough seats available" });

      // ── Distributed lock: prevents double-booking in high-concurrency ────────
      const lockKey = `seat_lock:${busId}:${seatNumbers.join(",")}`;
      const lockAcquired = await redis.set(lockKey, req.user.id, "NX", "EX", 600);
      if (!lockAcquired)
        return res.status(409).json({ success: false, message: "These seats are being booked by another user. Try again." });

      // ── Server-side fare calculation (cannot be overridden by client) ────────
      const { farePerSeat } = calculateFare(bus.route, bus.type, boardingStop, alightingStop);
      const totalFare = farePerSeat * passengerCount;
      const taxAmount = Math.round(totalFare * 0.05); // 5% GST
      const finalAmount = totalFare + taxAmount;

      // Create pending ticket
      const ticket = await Ticket.create({
        user: req.user.id,
        bus: busId,
        route: bus.route._id,
        boardingStop,
        alightingStop,
        journeyDate,
        seatNumbers,
        passengerCount,
        farePerSeat,
        totalFare,
        taxAmount,
        finalAmount,
        paymentStatus: "pending",
        status: "booked",
      });

      logger.info(`Booking initiated: ${ticket.ticketId} by user ${req.user.id}`);

      res.status(201).json({
        success: true,
        message: "Booking initiated. Complete payment within 10 minutes.",
        ticketId: ticket.ticketId,
        finalAmount,
        breakdown: { farePerSeat, totalFare, taxAmount, finalAmount },
        expiresIn: 600,
      });
    } catch (err) {
      next(err);
    }
  }
);

// ─── POST /api/bookings/confirm ───────────────────────────────────────────────
// Called after payment success to confirm ticket and generate QR
router.post("/confirm", authMiddleware, async (req, res, next) => {
  try {
    const { ticketId, paymentId, paymentMethod } = req.body;

    const ticket = await Ticket.findOne({ ticketId, user: req.user.id, paymentStatus: "pending" });
    if (!ticket)
      return res.status(404).json({ success: false, message: "Ticket not found or already confirmed" });

    // Decrement seats in DB
    await Bus.findByIdAndUpdate(ticket.bus, { $inc: { availableSeats: -ticket.passengerCount } });

    // Regenerate and verify integrity hash
    const expectedHash = ticket.generateIntegrityHash();

    // Generate QR code with encrypted ticket data
    const qrData = JSON.stringify({
      ticketId: ticket.ticketId,
      user: ticket.user,
      bus: ticket.bus,
      seats: ticket.seatNumbers,
      date: ticket.journeyDate,
      hash: expectedHash.substring(0, 16), // partial hash for QR validation
    });

    const qrCodeDataUrl = await QRCode.toDataURL(qrData, {
      errorCorrectionLevel: "H",
      margin: 2,
      color: { dark: "#1a1a2e", light: "#ffffff" },
    });

    ticket.paymentStatus = "paid";
    ticket.paymentId = paymentId;
    ticket.paymentMethod = paymentMethod;
    ticket.paidAt = new Date();
    ticket.status = "confirmed";
    ticket.qrCodeUrl = qrCodeDataUrl;
    await ticket.save();

    // Release Redis lock
    const redis = getRedis();
    await redis.del(`seat_lock:${ticket.bus}:${ticket.seatNumbers.join(",")}`).catch(() => {});

    logger.info(`Ticket confirmed: ${ticketId}`);

    res.json({
      success: true,
      message: "Ticket confirmed successfully!",
      ticket: {
        ticketId: ticket.ticketId,
        status: ticket.status,
        qrCode: ticket.qrCodeUrl,
        journeyDate: ticket.journeyDate,
        seatNumbers: ticket.seatNumbers,
        finalAmount: ticket.finalAmount,
      },
    });
  } catch (err) {
    next(err);
  }
});

// ─── DELETE /api/bookings/:ticketId ───────────────────────────────────────────
router.delete("/:ticketId", authMiddleware, async (req, res, next) => {
  try {
    const ticket = await Ticket.findOne({ ticketId: req.params.ticketId, user: req.user.id });
    if (!ticket) return res.status(404).json({ success: false, message: "Ticket not found" });

    if (ticket.status === "used")
      return res.status(400).json({ success: false, message: "Cannot cancel a used ticket" });

    // Refund policy: 100% if >24hrs, 50% if <24hrs
    const hoursToJourney = (ticket.journeyDate - Date.now()) / 3600000;
    const refundPercent = hoursToJourney > 24 ? 1.0 : 0.5;
    const refundAmount = ticket.paymentStatus === "paid"
      ? Math.round(ticket.finalAmount * refundPercent)
      : 0;

    ticket.status = "cancelled";
    ticket.cancelledAt = new Date();
    ticket.refundAmount = refundAmount;
    if (refundAmount > 0) ticket.paymentStatus = "refunded";
    await ticket.save();

    // Restore seats
    if (ticket.paymentStatus === "paid") {
      await Bus.findByIdAndUpdate(ticket.bus, { $inc: { availableSeats: ticket.passengerCount } });
    }

    res.json({ success: true, message: "Ticket cancelled", refundAmount });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
