const express = require("express");
const Ticket = require("../models/Ticket");
const { authMiddleware } = require("../middleware/auth");

const router = express.Router();

// GET /api/tickets — current user's tickets
router.get("/", authMiddleware, async (req, res, next) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const filter = { user: req.user.id };
    if (status) filter.status = status;

    const tickets = await Ticket.find(filter)
      .populate("bus", "busNumber type departureTime arrivalTime")
      .populate("route", "name source destination")
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Ticket.countDocuments(filter);

    res.json({
      success: true,
      data: tickets,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/tickets/:ticketId — single ticket detail
router.get("/:ticketId", authMiddleware, async (req, res, next) => {
  try {
    const ticket = await Ticket.findOne({ ticketId: req.params.ticketId, user: req.user.id })
      .populate("bus", "busNumber type departureTime arrivalTime currentStatus")
      .populate("route", "name source destination stops");

    if (!ticket) return res.status(404).json({ success: false, message: "Ticket not found" });
    res.json({ success: true, data: ticket });
  } catch (err) {
    next(err);
  }
});

// POST /api/tickets/:ticketId/verify — conductor verification
router.post("/:ticketId/verify", authMiddleware, async (req, res, next) => {
  try {
    if (req.user.role !== "conductor" && req.user.role !== "admin")
      return res.status(403).json({ success: false, message: "Not authorized" });

    const { hash } = req.body;
    const ticket = await Ticket.findOne({ ticketId: req.params.ticketId }).select("+integrityHash");
    if (!ticket) return res.status(404).json({ success: false, message: "Ticket not found" });

    if (ticket.status !== "confirmed")
      return res.status(400).json({ success: false, message: `Ticket is ${ticket.status}` });

    const isValid = ticket.verifyIntegrity(ticket.integrityHash);
    if (!isValid)
      return res.status(400).json({ success: false, valid: false, message: "Ticket integrity check failed — possible tampering detected" });

    ticket.status = "used";
    await ticket.save();

    res.json({ success: true, valid: true, message: "Ticket verified and marked as used", ticketId: ticket.ticketId });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
