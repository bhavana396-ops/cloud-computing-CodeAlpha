const Redis = require("ioredis");
const logger = require("./logger");

let redisClient;

const connectRedis = () => {
  redisClient = new Redis({
    host: process.env.REDIS_HOST || "127.0.0.1",
    port: parseInt(process.env.REDIS_PORT) || 6379,
    password: process.env.REDIS_PASSWORD || undefined,
    retryStrategy: (times) => Math.min(times * 100, 3000),
    maxRetriesPerRequest: 3,
    lazyConnect: false,
  });

  redisClient.on("connect", () => logger.info("✅ Redis connected"));
  redisClient.on("error", (err) => logger.error(`Redis error: ${err.message}`));
  redisClient.on("reconnecting", () => logger.warn("Redis reconnecting..."));

  return redisClient;
};

const getRedis = () => {
  if (!redisClient) throw new Error("Redis not initialized. Call connectRedis() first.");
  return redisClient;
};

module.exports = connectRedis;
module.exports.getRedis = getRedis;
