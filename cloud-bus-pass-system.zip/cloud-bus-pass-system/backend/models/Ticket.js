const mongoose = require("mongoose");
const crypto = require("crypto");

const ticketSchema = new mongoose.Schema(
  {
    ticketId: {
      type: String,
      unique: true,
      default: () => `TKT-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    bus: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Bus",
      required: true,
    },
    route: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Route",
      required: true,
    },
    boardingStop: { type: String, required: true },
    alightingStop: { type: String, required: true },
    journeyDate: { type: Date, required: true },
    seatNumbers: [{ type: String, required: true }],
    passengerCount: { type: Number, required: true, min: 1, max: 6 },

    // ── Pricing (server-side enforced) ──────────────────────────────────────
    farePerSeat: { type: Number, required: true },
    totalFare: { type: Number, required: true },
    taxAmount: { type: Number, default: 0 },
    finalAmount: { type: Number, required: true },

    // ── Payment ──────────────────────────────────────────────────────────────
    paymentStatus: {
      type: String,
      enum: ["pending", "paid", "failed", "refunded"],
      default: "pending",
    },
    paymentId: String,
    paymentMethod: { type: String, enum: ["card", "upi", "netbanking", "wallet"] },
    paidAt: Date,

    // ── Ticket Status ─────────────────────────────────────────────────────────
    status: {
      type: String,
      enum: ["booked", "confirmed", "used", "cancelled", "expired"],
      default: "booked",
    },
    cancelledAt: Date,
    refundAmount: Number,

    // ── Security — HMAC integrity hash ───────────────────────────────────────
    integrityHash: { type: String, select: false },

    // ── QR Code data URL (stored in S3, URL saved here) ─────────────────────
    qrCodeUrl: String,
  },
  { timestamps: true }
);

// ─── Generate HMAC integrity hash ─────────────────────────────────────────────
ticketSchema.methods.generateIntegrityHash = function () {
  const data = `${this.ticketId}|${this.user}|${this.bus}|${this.seatNumbers.join(",")}|${this.finalAmount}`;
  return crypto
    .createHmac("sha256", process.env.TICKET_SECRET || "default_secret")
    .update(data)
    .digest("hex");
};

// ─── Verify ticket hasn't been tampered with ──────────────────────────────────
ticketSchema.methods.verifyIntegrity = function (providedHash) {
  const expected = this.generateIntegrityHash();
  return crypto.timingSafeEqual(
    Buffer.from(expected, "hex"),
    Buffer.from(providedHash, "hex")
  );
};

// ─── Pre-save: compute integrity hash ────────────────────────────────────────
ticketSchema.pre("save", function (next) {
  if (this.isModified("finalAmount") || this.isNew) {
    this.integrityHash = this.generateIntegrityHash();
  }
  next();
});

// ─── Indexes for fast lookups ─────────────────────────────────────────────────
ticketSchema.index({ user: 1, journeyDate: -1 });
ticketSchema.index({ ticketId: 1 });
ticketSchema.index({ paymentStatus: 1, status: 1 });

module.exports = mongoose.model("Ticket", ticketSchema);
