const mongoose = require("mongoose");

// ─── Route Schema ─────────────────────────────────────────────────────────────
const routeSchema = new mongoose.Schema(
  {
    routeNumber: {
      type: String,
      required: true,
      unique: true,
      uppercase: true,
    },
    name: { type: String, required: true },
    source: { type: String, required: true },
    destination: { type: String, required: true },
    stops: [
      {
        name: String,
        distanceFromSource: Number, // km
        estimatedTime: Number,      // minutes from source
      },
    ],
    baseFare: { type: Number, required: true },   // INR per km
    totalDistance: { type: Number, required: true }, // km
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// ─── Bus Schema ───────────────────────────────────────────────────────────────
const busSchema = new mongoose.Schema(
  {
    busNumber: { type: String, required: true, unique: true },
    route: { type: mongoose.Schema.Types.ObjectId, ref: "Route", required: true },
    type: {
      type: String,
      enum: ["ordinary", "express", "ac", "luxury"],
      default: "ordinary",
    },
    totalSeats: { type: Number, required: true },
    availableSeats: { type: Number, required: true },
    departureTime: { type: Date, required: true },
    arrivalTime: { type: Date, required: true },
    currentStatus: {
      type: String,
      enum: ["scheduled", "boarding", "departed", "arrived", "cancelled"],
      default: "scheduled",
    },
    fareMultiplier: { type: Number, default: 1.0 }, // e.g. 1.5 for AC
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Virtual: fare for a given route distance
busSchema.methods.calculateFare = function (distance) {
  const route = this.populated("route") ? this.route : null;
  if (!route) throw new Error("Route not populated");
  const baseFare = route.baseFare * distance * this.fareMultiplier;
  return Math.ceil(baseFare / 5) * 5; // Round up to nearest ₹5
};

const Route = mongoose.model("Route", routeSchema);
const Bus = mongoose.model("Bus", busSchema);

module.exports = { Route, Bus };
