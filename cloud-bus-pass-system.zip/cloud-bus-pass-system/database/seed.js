/**
 * Seed script — populates the database with sample routes, buses, and an admin user.
 * Run: node database/seed.js
 */

require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("../backend/models/User");
const { Route, Bus } = require("../backend/models/Bus");

const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/buspass";

const routes = [
  {
    routeNumber: "MUM-PUN-01",
    name: "Mumbai Central → Pune",
    source: "Mumbai",
    destination: "Pune",
    baseFare: 1.5,
    totalDistance: 150,
    stops: [
      { name: "Mumbai Central", distanceFromSource: 0, estimatedTime: 0 },
      { name: "Khopoli", distanceFromSource: 55, estimatedTime: 70 },
      { name: "Lonavala", distanceFromSource: 83, estimatedTime: 100 },
      { name: "Pune", distanceFromSource: 150, estimatedTime: 180 },
    ],
  },
  {
    routeNumber: "BLR-MYS-02",
    name: "Bangalore → Mysore",
    source: "Bangalore",
    destination: "Mysore",
    baseFare: 1.2,
    totalDistance: 145,
    stops: [
      { name: "Bangalore", distanceFromSource: 0, estimatedTime: 0 },
      { name: "Channapatna", distanceFromSource: 60, estimatedTime: 75 },
      { name: "Maddur", distanceFromSource: 100, estimatedTime: 120 },
      { name: "Mysore", distanceFromSource: 145, estimatedTime: 170 },
    ],
  },
  {
    routeNumber: "DEL-AGR-03",
    name: "Delhi → Agra",
    source: "Delhi",
    destination: "Agra",
    baseFare: 1.3,
    totalDistance: 200,
    stops: [
      { name: "Delhi", distanceFromSource: 0, estimatedTime: 0 },
      { name: "Mathura", distanceFromSource: 140, estimatedTime: 150 },
      { name: "Agra", distanceFromSource: 200, estimatedTime: 210 },
    ],
  },
];

const seedDB = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("✅ Connected to MongoDB");

    // Clear existing data
    await Promise.all([User.deleteMany({}), Route.deleteMany({}), Bus.deleteMany({})]);
    console.log("🗑️  Cleared existing data");

    // Create routes
    const createdRoutes = await Route.insertMany(routes);
    console.log(`✅ Created ${createdRoutes.length} routes`);

    // Create buses for each route
    const now = new Date();
    const buses = createdRoutes.flatMap((route) => [
      {
        busNumber: `${route.routeNumber}-AC-001`,
        route: route._id,
        type: "ac",
        totalSeats: 40,
        availableSeats: 40,
        fareMultiplier: 1.8,
        departureTime: new Date(now.getTime() + 3600000 * 2),
        arrivalTime: new Date(now.getTime() + 3600000 * 5),
        currentStatus: "scheduled",
      },
      {
        busNumber: `${route.routeNumber}-EXP-002`,
        route: route._id,
        type: "express",
        totalSeats: 50,
        availableSeats: 50,
        fareMultiplier: 1.3,
        departureTime: new Date(now.getTime() + 3600000 * 4),
        arrivalTime: new Date(now.getTime() + 3600000 * 7),
        currentStatus: "scheduled",
      },
    ]);

    await Bus.insertMany(buses);
    console.log(`✅ Created ${buses.length} buses`);

    // Create admin user
    const admin = await User.create({
      name: "System Admin",
      email: "admin@buspass.cloud",
      phone: "9999999999",
      password: "Admin@1234",
      role: "admin",
      isVerified: true,
    });

    // Create demo passenger
    await User.create({
      name: "Demo User",
      email: "demo@buspass.cloud",
      phone: "9876543210",
      password: "Demo@1234",
      role: "passenger",
      isVerified: true,
    });

    console.log("✅ Created admin user: admin@buspass.cloud / Admin@1234");
    console.log("✅ Created demo user:  demo@buspass.cloud  / Demo@1234");
    console.log("\n🚌 Database seeded successfully!");

    await mongoose.connection.close();
    process.exit(0);
  } catch (err) {
    console.error("❌ Seeding failed:", err.message);
    process.exit(1);
  }
};

seedDB();
