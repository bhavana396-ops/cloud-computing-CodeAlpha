# 🚌 Cloud-Based Bus Pass System

> A scalable, cloud-native online bus ticket booking system built for reliability, security, and seamless user experience.

![Node.js](https://img.shields.io/badge/Node.js-18.x-green) ![Express](https://img.shields.io/badge/Express-4.x-blue) ![MongoDB](https://img.shields.io/badge/MongoDB-Atlas-brightgreen) ![AWS](https://img.shields.io/badge/AWS-EC2%20%7C%20S3%20%7C%20CloudFront-orange) ![License](https://img.shields.io/badge/License-MIT-yellow)

---

## 📌 Project Overview

This system addresses the shortcomings of traditional bus booking platforms by leveraging cloud infrastructure for:

- ✅ **No ticket loss** — QR-coded digital passes stored in the cloud
- ✅ **Theft prevention** — JWT-authenticated sessions + encrypted ticket tokens
- ✅ **Correct pricing** — Server-side fare calculation with audit logs
- ✅ **High traffic handling** — Auto-scaling via AWS EC2 Auto Scaling Groups
- ✅ **Real-time seat availability** — Redis-powered concurrency locking

---

## 🏗️ Architecture

```
User Browser / Mobile App
        │
        ▼
  CloudFront CDN  ──────► S3 Static Assets
        │
        ▼
  Load Balancer (AWS ALB)
        │
   ┌────┴────┐
   ▼         ▼
EC2 App   EC2 App    ← Auto Scaling Group
   │         │
   └────┬────┘
        ▼
   Redis Cache (ElastiCache)
        │
        ▼
   MongoDB Atlas (Primary DB)
        │
        ▼
   SNS / SES (Notifications)
```

---

## 🛠️ Tech Stack

| Layer        | Technology                          |
|-------------|-------------------------------------|
| Frontend     | HTML5, CSS3, Vanilla JS             |
| Backend      | Node.js + Express.js                |
| Database     | MongoDB Atlas (cloud-hosted)        |
| Cache        | Redis (AWS ElastiCache)             |
| Auth         | JWT + bcrypt                        |
| Payments     | Razorpay / Stripe                   |
| Notifications| Nodemailer (SES) + SMS (Twilio)     |
| Hosting      | AWS EC2, S3, CloudFront, ALB        |
| CI/CD        | GitHub Actions                      |
| Monitoring   | AWS CloudWatch                      |
| Containers   | Docker + Docker Compose             |

---

## 📁 Project Structure

```
cloud-bus-pass-system/
├── frontend/
│   ├── index.html              # Landing page
│   ├── pages/
│   │   ├── login.html
│   │   ├── register.html
│   │   ├── dashboard.html
│   │   ├── book-ticket.html
│   │   ├── my-passes.html
│   │   └── admin.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── auth.js
│       ├── booking.js
│       └── dashboard.js
├── backend/
│   ├── server.js               # Entry point
│   ├── config/
│   │   ├── db.js               # MongoDB connection
│   │   └── redis.js            # Redis connection
│   ├── models/
│   │   ├── User.js
│   │   ├── Ticket.js
│   │   ├── Bus.js
│   │   └── Route.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── booking.js
│   │   ├── tickets.js
│   │   └── admin.js
│   └── middleware/
│       ├── auth.js             # JWT verification
│       ├── rateLimit.js        # DDoS protection
│       └── errorHandler.js
├── database/
│   └── seed.js                 # Sample data seeder
├── tests/
│   ├── auth.test.js
│   └── booking.test.js
├── docs/
│   ├── API.md
│   └── DEPLOYMENT.md
├── .github/
│   └── workflows/
│       └── deploy.yml          # CI/CD Pipeline
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── package.json
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js v18+
- MongoDB Atlas account (free tier works)
- Redis (local or cloud)
- Git

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/cloud-bus-pass-system.git
cd cloud-bus-pass-system
```

### 2. Install Dependencies
```bash
cd backend
npm install
```

### 3. Configure Environment Variables
```bash
cp .env.example .env
# Edit .env with your credentials
```

### 4. Seed the Database
```bash
node database/seed.js
```

### 5. Start the Server
```bash
# Development
npm run dev

# Production
npm start
```

### 6. Run with Docker
```bash
docker-compose up --build
```

Access the app at: **http://localhost:5000**

---

## 🌐 Cloud Deployment (AWS)

Full deployment guide: [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)

**Quick summary:**
1. Push to `main` branch → GitHub Actions CI/CD triggers
2. Docker image built and pushed to AWS ECR
3. EC2 Auto Scaling Group pulls latest image
4. CloudFront CDN invalidates cache
5. Health checks confirm deployment

---

## 🔐 Security Features

| Feature | Implementation |
|---------|---------------|
| Password Hashing | bcrypt (12 salt rounds) |
| Auth Tokens | JWT (15min access + 7d refresh) |
| Ticket Integrity | HMAC-SHA256 signed QR codes |
| Rate Limiting | 100 req/15min per IP |
| SQL Injection | Mongoose schema validation |
| CORS | Whitelisted origins only |
| HTTPS | SSL via ACM + CloudFront |

---

## 📊 Scalability Design

- **Horizontal scaling**: Stateless Node.js instances behind ALB
- **Session management**: Redis (not in-memory) for shared state
- **DB scaling**: MongoDB Atlas auto-sharding + read replicas
- **CDN**: Static assets on CloudFront (sub-10ms latency globally)
- **Queue**: Bull.js job queue for email/SMS notifications
- **Concurrency lock**: Redis SETNX prevents double-booking

---

## 🧪 Testing

```bash
cd backend
npm test          # Run all tests
npm run test:watch  # Watch mode
```

---

## 📄 License

MIT License — free to use for educational and commercial purposes.

---

## 👨‍💻 Author

Built as part of Cloud Computing Internship Project  
**Institution**: [Your College Name]  
**Year**: 2024–25
